#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright (c) @Lululla 2026
# moon_calendar.py - Annual lunar phase calendar

from datetime import datetime, timedelta
from os.path import exists, join
from collections import defaultdict
from Screens.Screen import Screen
from Screens.HelpMenu import HelpableScreen
from Screens.MessageBox import MessageBox
from Components.ActionMap import HelpableActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.Sources.List import List
from Tools.LoadPixmap import LoadPixmap

from . import _, PLUGIN_PATH, load_skin_for_class, apply_global_theme
from .MoonPhase import MoonPhase
from .google_translate import trans


class MoonCalendar(Screen, HelpableScreen):
    def __init__(self, session, moon_obj=None):
        self.skin = load_skin_for_class(MoonCalendar)
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self.setTitle(_("Lunar Calendar"))
        self.moon = moon_obj or MoonPhase(
            icon_path=join(PLUGIN_PATH, "moon"),
            total_icons=101
        )
        self.phases = []
        self.list = []
        self["menu"] = List(self.list)
        self["background_plate"] = Label("")
        self["selection_overlay"] = Label("")
        self["info"] = Label(_("Loading lunar phases..."))
        self["Phase"] = Label(_("Phase"))
        self["Day"] = Label(_("Day"))
        self["Month"] = Label(_("Month"))
        self["Time"] = Label(_("Time"))

        self["current_phase_icon"] = Pixmap()
        self["current_phase_name"] = Label()
        self["current_illum"] = Label()
        self["current_distance"] = Label()
        self["illum_bar"] = ProgressBar()

        self["title"] = Label(_("Lunar phases from next phase"))
        self["actions"] = HelpableActionMap(
            self, "ForecaActions",
            {
                "cancel": (self.close, _("Exit")),
                "ok": (self.show_details, _("Details")),
                "up": (self["menu"].up, _("Move up")),
                "down": (self["menu"].down, _("Move down")),
                "pageUp": (self["menu"].pageUp, _("Page up")),
                "pageDown": (self["menu"].pageDown, _("Page down")),
            },
            -1
        )

        self.onLayoutFinish.append(self._apply_theme)
        self.onLayoutFinish.append(self.load_calendar)

    def _apply_theme(self):
        apply_global_theme(self)

    # -------------------------------------------------------------------------
    # Helper methods for special events
    # -------------------------------------------------------------------------

    def _is_supermoon(self, full_moon):
        """Return True if the full moon is a supermoon (distance <= 360000 km)."""
        return full_moon.get('distance', 999999) <= 360000

    def _get_blue_moons(self, full_moons):
        """Return list of blue moons (second full moon in a calendar month)."""
        by_month = defaultdict(list)
        for fm in full_moons:
            key = (fm['date'].year, fm['date'].month)
            by_month[key].append(fm)

        blue = []
        for month, fms in by_month.items():
            if len(fms) == 2:
                blue.append(fms[1])  # second is the blue moon
        return blue

    def _get_black_moons(self, new_moons):
        """Return list of black moons (second new moon in a calendar month)."""
        by_month = defaultdict(list)
        for nm in new_moons:
            key = (nm['date'].year, nm['date'].month)
            by_month[key].append(nm)

        black = []
        for month, nms in by_month.items():
            if len(nms) == 2:
                black.append(nms[1])
        return black

    def _get_perigee_for_month(self, year, month):
        """Find the perigee (minimum lunar distance) within the given month.

        Returns:
            dict | None: A dictionary containing date, distance, icon_path,
            phase_name, illumination, event_type, or None if no perigee found.
        """
        start = datetime(year, month, 1)
        if month == 12:
            end = datetime(year + 1, 1, 1) - timedelta(days=1)
        else:
            end = datetime(year, month + 1, 1) - timedelta(days=1)

        jd_start = self.moon._date_to_jd(start)
        jd_end = self.moon._date_to_jd(end)

        best_jd = None
        best_dist = float("inf")

        # Käytetään pienempää askelta kuin 1 päivä, esim. 0.1 d (~2.4 h)
        step = 0.1
        jd = jd_start
        while jd <= jd_end:
            data = self.moon._compute_lunar_data(jd)
            if data["distance"] < best_dist:
                best_dist = data["distance"]
                best_jd = jd
            jd += step

        if best_jd is not None:
            dt = self.moon._jd_to_date(best_jd)
            info = self.moon.get_phase_info_for_jd(best_jd)
            return {
                'date': dt,
                'distance': best_dist,
                'icon_path': info['icon_path'],
                'phase_name': info['name'],
                'illumination': info['illumination'],
                'event_type': 'Perigee'
            }
        return None

    def _load_eclipse_data(self):
        path = join(PLUGIN_PATH, "eclipse_data.json")
        if not exists(path):
            return []

        with open(path, "r") as f:
            raw = json.load(f)

        events = []
        for e in raw:
            dt = datetime.strptime(e["date"], "%Y-%m-%d %H:%M")

            # Valitse ikonit tyypin mukaan
            if e["type"] == "Total":
                icon = join(self.moon.icon_path, "bloodmoon.png")
            elif e["type"] == "Partial":
                icon = join(self.moon.icon_path, "partial_eclipse.png")
            else:
                icon = join(self.moon.icon_path, "penumbral.png")

            events.append({
                "date": dt,
                "phase_name": e["event_type"],
                "event_type": e["event_type"],
                "illumination": 100.0,
                "distance": None,
                "icon_path": icon
            })
        return events

    # -------------------------------------------------------------------------
    # Calendar generation
    # -------------------------------------------------------------------------

    def load_calendar(self):
        """Generate the list of lunar phases and special events for the next 12 months."""
        self["info"].setText(_("Calculating..."))
        self.phases = []
        today = datetime.now()
        eclipse_start = today
        eclipse_end = today + timedelta(days=365)
        start_day = today.day
        start_month = today.month
        start_year = today.year

        current = datetime(start_year, start_month, start_day)

        # Calculate for 12 months
        for i in range(12):
            month_phases = self._get_month_phases(current.year, current.month, current.day)
            self.phases.extend(month_phases)
            # Move to next month
            if current.month == 12:
                current = datetime(current.year + 1, 1, 1)
            else:
                current = datetime(current.year, current.month + 1, 1)

        # Collect full and new moons
        full_moons = [p for p in self.phases if p["phase_name"] == "Full Moon"]
        new_moons = [p for p in self.phases if p["phase_name"] == "New Moon"]

        # 1) Supermoons
        supermoons = [fm for fm in full_moons if self._is_supermoon(fm)]

        # 2) Blue moons
        blue_moons = self._get_blue_moons(full_moons)

        # 3) Black moons
        black_moons = self._get_black_moons(new_moons)

        eclipses = self._load_eclipse_data()
        eclipses = [e for e in eclipses if eclipse_start <= e["date"] <= eclipse_end]

        # 5) Perigees for each month
        perigees = []
        for year, month in {(p["date"].year, p["date"].month) for p in self.phases}:
            perigee_data = self._get_perigee_for_month(year, month)
            if perigee_data:
                perigees.append(perigee_data)

        # Add special events as new entries
        special_events = []

        for sm in supermoons:
            ev = sm.copy()
            ev["event_type"] = "Supermoon"
            ev["phase_name"] = "Supermoon"
            special_events.append(ev)

        for bm in blue_moons:
            ev = bm.copy()
            ev["event_type"] = "Blue Moon"
            ev["phase_name"] = "Blue Moon"
            special_events.append(ev)

        for bkm in black_moons:
            ev = bkm.copy()
            ev["event_type"] = "Black Moon"
            ev["phase_name"] = "Black Moon"
            special_events.append(ev)

        for ecl in eclipses:
            special_events.append(ecl)

        for pg in perigees:
            special_events.append(pg)

        # Merge all events and sort by date
        self.phases.extend(special_events)
        self.phases.sort(key=lambda x: x["date"])

        # Build the list for the Listbox
        self.list = []
        for p in self.phases:
            self.list.append(self._create_entry(p))

        # Update current moon info
        info = self.moon.get_phase_info()
        if info["icon_path"] and exists(info["icon_path"]):
            self["current_phase_icon"].instance.setPixmapFromFile(info["icon_path"])
        self["current_phase_name"].setText(_(info["name"]))
        self["current_illum"].setText(_("Illumination: {:.1f}%").format(info["illumination"]))
        self["current_distance"].setText(_("Distance: {} km").format(info["distance"]))
        self["illum_bar"].setValue(info["illumination"])

        self["menu"].setList(self.list)
        self["info"].setText(trans("Found {} lunar phases").format(len(self.phases)))

    def _create_entry(self, phase):
        """Create a UI entry tuple for a lunar phase or special event."""
        icon_path = phase.get("icon_path")
        event_type = phase.get("event_type")

        # For perigees, use a dedicated icon if available
        if event_type == "Perigee":
            custom_icon = join(self.moon.icon_path, "perigee.png")
            if exists(custom_icon):
                icon_path = custom_icon

        if icon_path and exists(icon_path):
            icon = LoadPixmap(cached=True, path=icon_path)
        else:
            icon = None

        date = phase["date"]
        month = date.strftime("%B %Y")
        day = date.strftime("%d")
        hour = date.strftime("%H:%M")

        if event_type == "Supermoon":
            phase_text = _("Super Full Moon") + " ★"
        elif event_type == "Blue Moon":
            phase_text = _("Blue Moon") + " ☆"
        elif event_type == "Black Moon":
            phase_text = _("Black Moon") + " ◇"
        elif event_type == "Perigee":
            phase_text = _("Perigee") + f" ({phase['distance']:.0f} km)"
        else:
            phase_text = _(phase["phase_name"])

        return (month, icon, phase_text, day, hour)

    def _get_month_phases(self, year, month, day):
        """Return the 4 main phases for the given month using
        synodic stepping + Meeus root refinement."""

        from datetime import datetime, timedelta

        target_phases = [0.0, 0.25, 0.5, 0.75]
        names = {
            0.0: "New Moon",
            0.25: "First Quarter",
            0.5: "Full Moon",
            0.75: "Last Quarter"
        }

        # Month boundaries
        start_dt = datetime(year, month, day)   # <-- aloita annetusta päivästä
        if month == 12:
            end_of_month = datetime(year + 1, 1, 1) - timedelta(days=1)
        else:
            end_of_month = datetime(year, month + 1, 1) - timedelta(days=1)

        jd_start = self.moon._date_to_jd(start_dt)
        jd_end = self.moon._date_to_jd(end_of_month)

        # Reference full moon (same as original plugin)
        jd_ref = self.moon._date_to_jd(datetime(2026, 3, 19, 1, 23, 0))

        month_phases = []

        for target in target_phases:
            # Rough guess for first occurrence
            jd_phase = self._find_next_phase_after(jd_start, target, jd_ref)

            # Loop through all occurrences in this month
            while jd_phase <= jd_end + self.moon.SYNODIC_MONTH:
                target_angle = target * 360.0

                # Meeus root refinement
                jd_exact = self.moon.find_phase_time(jd_phase, target_angle)
                dt_phase = self.moon._jd_to_date(jd_exact)

                # Hyväksy vain tulevat vaiheet (ei menneitä)
                if dt_phase.year == year and dt_phase.month == month and dt_phase >= start_dt:
                    info = self.moon.get_phase_info_for_jd(jd_exact)
                    month_phases.append({
                        'date': dt_phase,
                        'phase_name': names[target],
                        'icon_path': info['icon_path'],
                        'jd': jd_exact,
                        'illumination': info['illumination'],
                        'distance': info['distance']
                    })

                # Move to next synodic cycle
                jd_phase += self.moon.SYNODIC_MONTH

        month_phases.sort(key=lambda x: x['date'])
        return month_phases

    def _find_next_phase_after(self, jd_start, target_phase, jd_ref=None):
        """
        Return a Meeus-style k-index based rough guess for the next phase.
        This completely replaces the old synodic-month based guess.
        """

        # Meeus: k = (JD - 2451550.09765) / SYNODIC_MONTH
        # 2451550.09765 = New Moon 2000 Jan 6 18:14 UT
        k = (jd_start - 2451550.09765) / self.moon.SYNODIC_MONTH

        # Move to next integer cycle
        k = int(k - (k % 1)) + target_phase

        # Convert back to JD
        jd_guess = 2451550.09765 + k * self.moon.SYNODIC_MONTH

        return jd_guess


    def show_details(self):
        idx = self["menu"].getSelectedIndex()
        if idx < 0 or idx >= len(self.phases):
            return
        phase = self.phases[idx]
        phase_name = _(phase['phase_name'])
        details = trans("Phase: {}").format(phase_name) + "\n"
        details += trans("Date: {}").format(phase['date'].strftime("%d.%m.%Y")) + "\n"
        details += trans("Time: {}").format(phase['date'].strftime("%H:%M")) + "\n"
        details += trans("Illumination: {:.1f}%").format(phase['illumination']) + "\n"
        details += trans("Distance: {} km").format(phase['distance'])
        self.session.open(MessageBox, details, MessageBox.TYPE_INFO)

    def exit(self):
        self.close()