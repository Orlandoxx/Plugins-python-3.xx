#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# daily_forecast.py - Weekly detailed forecast screen

from os.path import join, exists
from Screens.Screen import Screen
from Screens.HelpMenu import HelpableScreen
from Screens.MessageBox import MessageBox

from Components.ActionMap import HelpableActionMap
from Components.Label import Label
from Components.Sources.List import List

from Tools.LoadPixmap import LoadPixmap

from . import (
    _,
    load_skin_for_class,
    apply_global_theme,
    PLUGIN_PATH,
    get_icon_path
)
from .google_translate import (
    _get_system_language,
    translate_batch_strings,
    trans,
    translate_location
)
from .foreca_weather_api import _symbol_to_description


def _celsius_to_fahrenheit(c):
    return (c * 9.0 / 5.0) + 32

def _degrees_to_cardinal(deg):
    try:
        deg = round(deg) % 360
        directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
        return directions[round(deg / 45) % 8]
    except BaseException:
        return 'N'

def _translate_wind_direction(dir_code):
    mapping = {
        "N": _("north"),
        "NE": _("northeast"),
        "E": _("east"),
        "SE": _("southeast"),
        "S": _("south"),
        "SW": _("southwest"),
        "W": _("west"),
        "NW": _("northwest"),
    }
    return mapping.get(dir_code, dir_code)

def _translate_place(town, country):
    # 1) Kaupungille annetaan konteksti, jotta Google Translate kääntää sen
    town_ctx = f"city name (proper noun): {town}"

    # 2) Maa/maanosa käännetään trans():lla
    country_translated = trans(country + ":").replace(":", "").strip() if country else ""

    # 3) Batch-käännös kaupungille
    town_translated = translate_batch_strings([town_ctx])[0]
    town_translated = town_translated.split(": ", 1)[-1]  # poista kontekstiosa

    if country_translated:
        return f"{town_translated}, {country_translated}"
    else:
        return town_translated


class DailyForecast(Screen, HelpableScreen):
    def __init__(self, session, api, location_id, location_name):
        self.skin = load_skin_for_class(DailyForecast)
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self.api = api
        self.location_id = location_id
        self.location_name = location_name
        place = self.api.get_location_by_id(location_id)
        self.town = place.name
        self.country = place.country_name
        self.forecast_days = []
        self.list = []
        city_tr = translate_location(self.town, self.country)
        # print("city_tr .", city_tr)
        self.setTitle(_("Weekly Forecast") + " - " + city_tr)
        self["title"] = Label("")
        self["info"] = Label(_("Loading weekly forecast..."))
        self["menu"] = List(self.list)
        self["background_plate"] = Label("")
        self["selection_overlay"] = Label("")
        self["actions"] = HelpableActionMap(
            self, "ForecaActions",
            {
                "cancel": (self.exit, _("Exit")),
                "ok": (self.show_day_details, _("Details")),
                "up": (self["menu"].up, _("Move up")),
                "down": (self["menu"].down, _("Move down")),
                "pageUp": (self["menu"].pageUp, _("Page up")),
                "pageDown": (self["menu"].pageDown, _("Page down")),
            },
            -1
        )

        self.onLayoutFinish.append(self.load_forecast)
        self.onLayoutFinish.append(self._apply_theme)

    def _apply_theme(self):
        apply_global_theme(self)

    def load_forecast(self):
        self["info"].setText(_("Loading weekly forecast..."))
        try:
            self.forecast_days = self.api.get_daily_forecast(
                self.location_id, days=7)
        except Exception as e:
            print(f"[DailyForecast] API error: {e}")
            self.forecast_days = []

        if not self.forecast_days:
            self["info"].setText(_("Could not load forecast data"))
            return

        town_val = getattr(self, "town", "")
        country_val = getattr(self, "country", "")
        full_loc = f"{town_val}, {country_val}" if country_val and country_val != 'N/A' else town_val
        translated_location = _translate_place(town_val, country_val)

        self["title"].setText(f"{translated_location} - {_('7 Day Forecast')}")
        self["info"].setText(_("Use arrow keys to scroll"))

        self.list = []
        self.list.append(self._create_header_entry())
        # Days
        for day in self.forecast_days:
            self.list.append(self._create_day_entry(day))
        self.list.append(self._create_footer_entry())

        self["menu"].setList(self.list)

    def _create_header_entry(self):
        return (
            None,                   # 0: icon (none)
            _("Day"),               # 1: day
            _("Temp"),              # 2: temperature
            _("Weather"),           # 3: description
            _("Precipitation"),     # 4: precipitation
            None,                   # 5: (no icon)
            _("Wind"),              # 6: wind
        )

    def _create_day_entry(self, day):
        # Date and day
        date_str = day.date.strftime("%d.%m") if day.date else "??.??"
        day_name = _(day.date.strftime("%A")) if day.date else "???"
        day_display = f"{day_name} {date_str}"

        # Temperature with unit
        if hasattr(self.api, 'unit_manager') and self.api.unit_manager:
            min_val, temp_unit = self.api.unit_manager.convert_temperature(
                day.min_temp)
            max_val, _unused = self.api.unit_manager.convert_temperature(
                day.max_temp)
            temp_str = f"{round(min_val)} - {round(max_val)}{temp_unit}"
        else:
            temp_str = f"{day.min_temp} - {day.max_temp}°C"

        # Weather description
        desc = _symbol_to_description(day.condition)
        weather = trans(desc)
        if len(weather) > 70:
            weather = weather[:70] + "."

        # Weather icon
        icon_path = get_icon_path(f"{day.condition}.png")
        if icon_path:
            icon = LoadPixmap(cached=True, path=icon_path)
        else:
            icon = None

        # Precipitation
        if hasattr(self.api, 'unit_manager') and self.api.unit_manager:
            precip_val, precip_unit = self.api.unit_manager.convert_precipitation(
                day.precipitation)
            precip = f"{precip_val:.1f} {precip_unit}"
        else:
            precip = f"{day.precipitation} mm"

        # Icona vento
        wind_icon_name = "w" + _degrees_to_cardinal(day.wind_direction)
        wind_icon_path = join(PLUGIN_PATH, "thumb", f"{wind_icon_name}.png")
        if not exists(wind_icon_path):
            wind_icon_path = join(PLUGIN_PATH, "thumb", "wN.png")
        wind_icon = LoadPixmap(cached=True, path=wind_icon_path)

        # Wind
        wind_dir = _degrees_to_cardinal(day.wind_direction)
        wind_dir_tr = _translate_wind_direction(wind_dir)
        if hasattr(self.api, 'unit_manager') and self.api.unit_manager:
            wind_val, wind_unit = self.api.unit_manager.convert_wind(
                day.wind_speed)
            wind_val = round(wind_val)
            wind_str = f"{wind_val} {wind_unit} {wind_dir_tr}"
        else:
            wind_val = round(day.wind_speed * 3.6)
            wind_str = f"{wind_val} km/h {wind_dir_tr}"

        return (
            icon,          # 0
            day_display,   # 1
            temp_str,      # 2
            weather,       # 3
            precip,        # 4
            wind_icon,     # 5
            wind_str,      # 6
        )

    def _create_footer_entry(self):
        return (
            None,
            "",
            "",
            _("Data provided by Foreca"),
            "",
            None,
            ""
        )

    def show_day_details(self):
        idx = self["menu"].getIndex()
        if idx <= 0 or idx >= len(self.forecast_days) + 1:
            return
        day = self.forecast_days[idx - 1]

        lines = []
        lines.append(_("Date: {}").format(day.date))

        # --- Temperature with conversion ---
        if hasattr(self.api, 'unit_manager') and self.api.unit_manager:
            min_val, temp_unit = self.api.unit_manager.convert_temperature(
                day.min_temp)
            max_val, unused = self.api.unit_manager.convert_temperature(
                day.max_temp)
            temp_str = f"{round(min_val)}-{round(max_val)}{temp_unit}"
        else:
            temp_str = f"{day.min_temp}-{day.max_temp}°C"
        lines.append(_("Temperature: {}").format(temp_str))

        # --- Wind with conversion ---
        if hasattr(self.api, 'unit_manager') and self.api.unit_manager:
            wind_val, wind_unit = self.api.unit_manager.convert_wind(
                day.wind_speed)
            wind_val = round(wind_val, 1)
            wind_dir = _degrees_to_cardinal(day.wind_direction)
            wind_str = f"{wind_val} {wind_unit} {wind_dir}"
        else:
            wind_str = f"{day.wind_speed} km/h {_degrees_to_cardinal(day.wind_direction)}"
        lines.append(_("Wind: {}").format(wind_str))

        # --- Precipitation (already converted) ---
        if hasattr(self.api, 'unit_manager') and self.api.unit_manager:
            precip_val, precip_unit = self.api.unit_manager.convert_precipitation(
                day.precipitation)
            precip_str = f"{precip_val:.1f}{precip_unit}"
        else:
            precip_str = f"{day.precipitation} mm"
        lines.append(_("Precipitation: {}").format(precip_str))

        lines.append(_("Humidity: {}%").format(day.humidity))
        lines.append(
            _("Condition: {}").format(
                trans(
                    _symbol_to_description(
                        day.condition))))

        details = "\n".join(lines)
        self.session.open(MessageBox, details, MessageBox.TYPE_INFO)

    def exit(self):
        self.close()
