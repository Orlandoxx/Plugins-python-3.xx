#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright (c) @Lululla 2026
# MoonPhase.py - Astronomical constants with precise calculations

import glob
import time
import datetime
from os.path import exists, join, isdir, basename
from time import mktime, localtime
from math import pi, cos, radians, sin, atan2, degrees, tan, asin
from threading import Thread
import requests
from zoneinfo import ZoneInfo

from . import _


MOON_PHASES = {
    "New Moon": _("New Moon"),
    "Waxing Crescent": _("Waxing Crescent"),
    "First Quarter": _("First Quarter"),
    "Waxing Gibbous": _("Waxing Gibbous"),
    "Full Moon": _("Full Moon"),
    "Waning Gibbous": _("Waning Gibbous"),
    "Last Quarter": _("Last Quarter"),
    "Waning Crescent": _("Waning Crescent"),
}


class MoonPhase:
    # Astronomical constants
    SYNODIC_MONTH = 29.530588853  # days between two new moons
    # Reference date: New Moon on January 6, 2000 at 20:14 UTC
    NEW_MOON_REF = (2000, 1, 6, 20, 14, 0, 0, 0, 0)  # struct_time

    def __init__(self, icon_path=None, total_icons=101):
        """
        icon_path: absolute path to the folder containing the icons (moon0000.png ... moon0100.png)
        total_icons: total number of icons (default 101, from 0 to 100)
        """
        self.icon_path = icon_path
        self.total_icons = total_icons
        self.api_data = None  # stores data obtained from the USNO API

    def _moon_phase_to_icon(self, phase_name, illum_percent):
        """
        Maps the phase name and illumination percentage (0-100)
        to the icon index (0-100) according to your icon sequence.
        """

        # Indicative centers of the main phases
        phase_centers = {
            "New Moon": 0,
            "Waxing Crescent": 12,
            "First Quarter": 25,
            "Waxing Gibbous": 37,
            "Full Moon": 50,
            "Waning Gibbous": 62,
            "Last Quarter": 75,
            "Waning Crescent": 87,
        }

        # Special cases with linear variation
        if phase_name == "New Moon":
            # Very close to 0% or 100%
            return 0 if illum_percent < 10 else 100

        elif phase_name == "Waxing Crescent":
            # illum from 0% to 50% -> icons from 0 to 25
            return int(illum_percent * 25 / 50)

        elif phase_name == "First Quarter":
            return 25

        elif phase_name == "Waxing Gibbous":
            # illum from 50% to 100% -> icons from 25 to 50
            return int(25 + (illum_percent - 50) * 25 / 50)

        elif phase_name == "Full Moon":
            return 50

        elif phase_name == "Waning Gibbous":
            # illum from 100% to 50% -> icons from 50 to 75
            return int(50 + (100 - illum_percent) * 25 / 50)

        elif phase_name == "Last Quarter":
            return 75

        elif phase_name == "Waning Crescent":
            # illum from 50% to 0% -> icons from 75 to 100
            return int(75 + (50 - illum_percent) * 25 / 50)

        else:
            # fallback to center
            return phase_centers.get(phase_name, 50)

    # -------------------------------------------------------------------------
    # Precise lunar calculations (based on Meeus / external code)
    # -------------------------------------------------------------------------

    def _date_to_jd(self, dt):
        """
        Convert a datetime (assumed UTC) to Julian Day, consistent with _get_julian_day.
        """
        year = dt.year
        month = dt.month
        day = dt.day + (dt.hour + dt.minute / 60.0 + dt.second / 3600.0) / 24.0

        if month <= 2:
            year -= 1
            month += 12

        A = year // 100
        B = 2 - A + A // 4

        jd = int(365.25 * (year + 4716)) \
            + int(30.6001 * (month + 1)) \
            + day + B - 1524.5

        return jd

    def _jd_to_date(self, jd):
        """Convert a Julian Day value to a datetime object.

        Uses the same conversion formula as MoonCalendar.
        """
        from datetime import datetime

        jd = jd + 0.5
        z = int(jd)
        f = jd - z

        if z < 2299161:
            a = z
        else:
            alpha = int((z - 1867216.25) / 36524.25)
            a = z + 1 + alpha - int(alpha / 4)

        b = a + 1524
        c = int((b - 122.1) / 365.25)
        d = int(365.25 * c)
        e = int((b - d) / 30.6001)

        day = int(b - d - int(30.6001 * e) + f)
        month = int(e - 1 if e < 14 else e - 13)
        year = int(c - 4716 if month > 2 else c - 4715)

        total_seconds = int(f * 86400)
        seconds = total_seconds % 60
        minutes = (total_seconds // 60) % 60
        hours = total_seconds // 3600

        return datetime(year, month, day, hours, minutes, seconds)

    def _compute_lunar_data(self, jd):
        """
        High‑accuracy Meeus lunar model (Ch. 47–49)
        Accuracy: ±5 minutes for lunar phases.
        """

        # ΔT (approx) – Meeus formula for 2005–2050
        t = (jd - 2451545.0) / 36525.0
        year = 2000 + t * 100
        delta_t = 62.92 + 0.32217 * (year - 2000) + 0.005589 * (year - 2000)**2

        # Convert JD → dynamical time (TT)
        jd_tt = jd + delta_t / 86400.0
        T = (jd_tt - 2451545.0) / 36525.0

        # Sun mean longitude & anomaly
        Ls = (280.46646 + 36000.76983*T + 0.0003032*T*T) % 360
        Ms = (357.52911 + 35999.05029*T - 0.0001537*T*T) % 360

        # Sun true longitude
        lambda_sun = (
            Ls
            + 1.914602 * sin(radians(Ms))
            + 0.019993 * sin(radians(2 * Ms))
            + 0.000289 * sin(radians(3 * Ms))
        )

        # Moon mean elements
        Lm = (218.3164477 + 481267.88123421*T
              - 0.0015786*T*T + T*T*T/538841) % 360
        Mm = (134.9633964 + 477198.8675055*T
              + 0.0087414*T*T + T*T*T/69699) % 360
        D = (297.8501921 + 445267.1114034*T
             - 0.0018819*T*T + T*T*T/545868) % 360
        F = (93.2720950 + 483202.0175233*T
             - 0.0036539*T*T - T*T*T/3526000) % 360

        # Meeus 47 full series (47 terms)
        terms = [
            (6.289,      1,  0,  0,  0),
            (1.274,      2, -1,  0,  0),
            (0.658,      2,  0,  0,  0),
            (0.214,      0,  2,  0,  0),
            (-0.186,     0,  0,  1,  0),
            (-0.059,     2, -2,  0,  0),
            (-0.057,     2, -1, -1,  0),
            (0.053,      2,  1,  0,  0),
            (0.046,      2, -1,  1,  0),
            (0.041,      0,  1, -1,  0),
            (-0.035,     1,  0,  1,  0),
            (-0.031,     0, -1, -1,  0),
            (-0.015,     1,  1,  0,  0),
            (0.011,      2,  0, -1,  0),
            (-0.011,     1, -1,  0,  0),
            (-0.010,     0,  1,  1,  0),
            (-0.007,     1,  0, -1,  0),
            (0.007,      0, -1,  1,  0),
            (-0.006,     1,  1, -1,  0),
            (-0.005,     1, -1,  1,  0),
            (-0.004,     1,  0,  2,  0),
            (0.004,      2,  1, -1,  0),
            (0.004,      2, -1, -2,  0),
            (0.003,      2, -2, -1,  0),
            (0.003,      2,  0,  1,  0),
            (0.003,      0,  2, -1,  0),
            (0.003,      2,  2, -1,  0),
            (0.002,      2,  1,  1,  0),
            (0.002,      2, -1,  2,  0),
            (0.002,      2, -3,  0,  0),
            (0.002,      0,  1, -2,  0),
            (0.002,      0,  3, -1,  0),
            (0.002,      1,  1,  1,  0),
            (0.001,      1,  1, -2,  0),
            (0.001,      1, -2,  0,  0),
            (0.001,      2,  2, -2,  0),
            (0.001,      2,  0, -2,  0),
            (0.001,      2, -2,  1,  0),
            (0.001,      0,  2,  1,  0),
            (0.001,      1,  0, -2,  0),
            (0.001,      1,  2,  0,  0),
            (0.001,      2,  1,  0, -1),
            (0.001,      2, -1,  0, -1),
            (0.001,      2,  0,  0, -1),
            (0.001,      0,  1,  0, -1),
            (0.001,      1,  0,  0, -1),
        ]

        lambda_moon = Lm
        for A, dD, dM, dMs, dF in terms:
            lambda_moon += A * sin(radians(dD * D + dM * Mm + dMs * Ms + dF * F))

        # Elongation
        delta_lambda = (lambda_moon - lambda_sun + 360) % 360

        # Illumination
        illumination = (1 - cos(radians(delta_lambda))) * 50

        # Distance (Meeus full series)
        distance = (
            385000.56
            - 20905.0 * cos(radians(Mm))
            - 3699.0 * cos(radians(2 * D - Mm))
            - 2956.0 * cos(radians(2 * D))
            - 570.0 * cos(radians(2 * Mm))
            + 246.0 * cos(radians(2 * D - 2 * Mm))
        )

        # Phase name
        if delta_lambda < 10 or delta_lambda > 350:
            phase_name = "New Moon"
        elif delta_lambda < 80:
            phase_name = "Waxing Crescent"
        elif delta_lambda < 100:
            phase_name = "First Quarter"
        elif delta_lambda < 170:
            phase_name = "Waxing Gibbous"
        elif delta_lambda < 190:
            phase_name = "Full Moon"
        elif delta_lambda < 260:
            phase_name = "Waning Gibbous"
        elif delta_lambda < 280:
            phase_name = "Last Quarter"
        else:
            phase_name = "Waning Crescent"

        return {
            "illumination": illumination,
            "phase_name": phase_name,
            "distance": int(distance),
            "trend": 1 if delta_lambda < 180 else -1,
            "phase": delta_lambda / 360.0,
            "lambda_moon": lambda_moon
        }

    def _get_current_phase_value(self):
        # This method is kept for compatibility but not used in precise mode
        # We'll still use it if needed, but better to use precise.
        ref_time = mktime(self.NEW_MOON_REF)
        ref_days = ref_time / 86400.0
        now_days = mktime(localtime()) / 86400.0
        days_since_ref = now_days - ref_days
        phase = (days_since_ref % self.SYNODIC_MONTH) / self.SYNODIC_MONTH
        return phase

    def _illumination_from_phase(self, phase):
        return (1 - cos(2 * pi * phase)) / 2 * 100

    def _get_phase_name(self, phase):
        # Approximate phase names
        if phase < 0.03 or phase >= 0.97:
            return "New Moon"
        elif phase < 0.22:
            return "Waxing Crescent"
        elif phase < 0.28:
            return "First Quarter"
        elif phase < 0.47:
            return "Waxing Gibbous"
        elif phase < 0.53:
            return "Full Moon"
        elif phase < 0.72:
            return "Waning Gibbous"
        elif phase < 0.78:
            return "Last Quarter"
        else:
            return "Waning Crescent"

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------
    def get_phase_info(self, target_date=None):
        if target_date is None:
            target_date = datetime.datetime.utcnow()
        elif isinstance(target_date, datetime.date) and not isinstance(
                target_date, datetime.datetime):
            # If it's a date without a time, set the time to 00:00:00 UTC
            target_date = datetime.datetime(
                target_date.year, target_date.month, target_date.day, 0, 0, 0)

        # Precise calculation
        jd = self._get_julian_day(target_date)
        data = self._compute_lunar_data(jd)
        illumination = data['illumination']
        name = data['phase_name']
        distance = data['distance']
        # Map illumination to icon using the same logic as API case
        crescente = data['trend'] == 1
        if crescente:
            icon_number = int(round(illumination * 50 / 100))
        else:
            icon_number = int(round(50 + (100 - illumination) * 50 / 100))
        if name == "New Moon":
            icon_number = 0 if illumination < 10 else 100
        elif name == "Full Moon":
            icon_number = 50
        icon_number = max(0, min(100, icon_number))

        # Find icon file
        icon_file = None
        if self.icon_path:
            icon_file = join(self.icon_path, f"moon{icon_number:04d}.png")
            if not exists(icon_file):
                icon_file = self._find_nearest_icon(icon_number)

        return {
            "illumination": illumination,
            "name": name,
            "icon_number": icon_number,
            "icon_path": icon_file,
            "distance": distance
        }

    def _get_julian_day(self, t=None):
        if t is None:
            dt = datetime.datetime.utcnow()   # KÄYTÄ UTC-AIKAA
        else:
            dt = t if isinstance(t, datetime.datetime) else datetime.datetime.utcfromtimestamp(t)

        year = dt.year
        month = dt.month
        day = dt.day + (dt.hour + dt.minute / 60.0 + dt.second / 3600.0) / 24.0

        if month <= 2:
            year -= 1
            month += 12

        A = year // 100
        B = 2 - A + A // 4
        JD = int(365.25 * (year + 4716)) + int(30.6001 * (month + 1)) + day + B - 1524.5
        return JD

    def get_phase_info_for_jd(self, jd):
        """
        Returns lunar information for a given Julian Day.
        Similar to get_phase_info() but based on the specified JD.
        """
        data = self._compute_lunar_data(jd)
        illumination = data['illumination']
        # already calculated in _compute_lunar_data
        phase_name = data['phase_name']
        distance = data['distance']
        trend = data['trend']

        # Map illumination to icon (0–100) linearly, with corrections for the main phases
        # The icon must be consistent with the phase name.
        if phase_name == "New Moon":
            icon_number = 0 if illumination < 10 else 100
        elif phase_name == "Waxing Crescent":
            # illumination from ~0 to 50% → icon from 0 to 25
            icon_number = int(round(illumination * 25 / 50))
        elif phase_name == "First Quarter":
            icon_number = 25
        elif phase_name == "Waxing Gibbous":
            # illumination from ~50 to 100% → icon from 25 to 50
            icon_number = int(round(25 + (illumination - 50) * 25 / 50))
        elif phase_name == "Full Moon":
            icon_number = 50
        elif phase_name == "Waning Gibbous":
            # illumination from 100 to 50% → icon from 50 to 75
            icon_number = int(round(50 + (100 - illumination) * 25 / 50))
        elif phase_name == "Last Quarter":
            icon_number = 75
        elif phase_name == "Waning Crescent":
            # illumination from 50 to 0% → icon from 75 to 100
            icon_number = int(round(75 + (50 - illumination) * 25 / 50))
        else:
            # fallback (should not happen)
            waxing = (trend == 1)
            if waxing:
                icon_number = int(round(illumination * 50 / 100))
            else:
                icon_number = int(round(50 + (100 - illumination) * 50 / 100))
            icon_number = max(0, min(100, icon_number))

        # Ensure the icon number stays within the 0–100 range
        icon_number = max(0, min(100, icon_number))

        icon_file = None
        if self.icon_path:
            icon_file = join(self.icon_path, f"moon{icon_number:04d}.png")
            if not exists(icon_file):
                icon_file = self._find_nearest_icon(icon_number)

        return {
            'illumination': illumination,
            'name': phase_name,
            'distance': distance,
            'icon_number': icon_number,
            'icon_path': icon_file,
            'jd': jd,
            'trend': trend,
            'phase': data['phase']
        }

    # -------------------------------------------------------------------------
    # API methods (unchanged)
    # -------------------------------------------------------------------------
    def get_moon_data_async(
            self,
            lat,
            lon,
            callback,
            max_days=2,
            offset_hours=None,
            date=None):
        def worker():
            result = self.get_moon_data_from_api(
                lat, lon, max_days, offset_hours, date)
            if callback:
                callback(result)
        Thread(target=worker).start()

    def get_moon_data_from_api(
            self,
            lat,
            lon,
            max_days=2,
            offset_hours=None,
            date=None):
        if offset_hours is None:
            offset_hours = self._get_offset_hours()
        try:
            base_date = date if date is not None else datetime.date.today()
            moonrise = "N/A"
            moonset = "N/A"
            phase_name = "N/A"
            illumination = None
            for days_offset in range(max_days + 1):
                check_date = base_date + datetime.timedelta(days=days_offset)
                date_str = check_date.strftime("%Y-%m-%d")
                url = "https://aa.usno.navy.mil/api/rstt/oneday"
                params = {
                    "date": date_str,
                    "coords": f"{lat}, {lon}",
                    "tz": str(offset_hours),
                    "dst": "false"
                }
                try:
                    response = requests.get(url, params=params, timeout=10)
                    if response.status_code != 200:
                        continue
                    data = response.json()
                    props = data.get("properties", {}).get("data", {})
                    if not props:
                        continue
                    if days_offset == 0:
                        phase_name = props.get("curphase", "N/A")
                        illum_str = props.get(
                            "fracillum", "0%").replace(
                            "%", "").strip()
                        illumination = float(
                            illum_str) / 100.0 if illum_str != "N/A" else None
                    for item in props.get("moondata", []):
                        phen = item.get("phen", "")
                        time_val = item.get("time", "N/A")
                        if phen == "Rise" and moonrise == "N/A":
                            moonrise = time_val
                        elif phen == "Set" and moonset == "N/A":
                            moonset = time_val
                    if moonrise != "N/A" and moonset != "N/A":
                        break
                except Exception as e:
                    print(f"[Moon] API error: {e}")
            result = {
                "rise": moonrise,
                "set": moonset,
                "phase": phase_name,
                "illumination": illumination
            }
            if illumination is not None:
                self.api_data = result
            return result
        except Exception as e:
            print(f"[Moon] Exception in API: {e}")
            return None

    def _get_offset_hours(self):
        lt = time.localtime()
        if lt.tm_isdst:
            offset_sec = -time.altzone
        else:
            offset_sec = -time.timezone
        return round(offset_sec / 3600.0, 1)

    def get_moon_distance(self):
        # Use precise calculation
        jd = self._get_julian_day()
        return self._compute_lunar_data(jd)['distance']

    def _find_nearest_icon(self, target_num):
        if not self.icon_path or not isdir(self.icon_path):
            return None
        pattern = join(self.icon_path, "moon*.png")
        files = glob.glob(pattern)
        numbers = []
        for f in files:
            base = basename(f)
            num_str = base.replace('moon', '').replace('.png', '')
            if num_str.isdigit():
                numbers.append((int(num_str), f))
        if not numbers:
            return None
        nearest = min(numbers, key=lambda x: abs(x[0] - target_num))
        return nearest[1]

    def _elongation_deg(self, jd):
        """Return elongation angle Δλ (degrees) between Moon and Sun."""
        data = self._compute_lunar_data(jd)
        # Δλ = phase * 360
        return (data["phase"] * 360.0) % 360.0

    def find_phase_time(self, jd_guess, target_angle_deg):
        """
        Meeus Newton–Raphson iteration to find exact moment when
        elongation = target_angle_deg (0, 90, 180, 270).
        """
        jd = jd_guess

        for i in range(12):  # 6–12 kierrosta riittää NASA-tarkkuuteen
            e = self._elongation_deg(jd)
            f = (e - target_angle_deg + 540) % 360 - 180  # erotus -180..+180

            if abs(f) < 1e-7:  # alle 0.0000001 astetta → valmis
                break

            # Derivaatta: d(Δλ)/dt ≈ (Δλ(jd+Δ) - Δλ(jd-Δ)) / (2Δ)
            delta = 0.0001  # ~8.6 sekuntia
            e1 = self._elongation_deg(jd + delta)
            e2 = self._elongation_deg(jd - delta)
            derivative = (e1 - e2) / (2 * delta)

            if derivative == 0:
                break

            jd -= f / derivative

        return jd

    def get_new_moon_before(self, jd_now):
        """
        Returns the Julian Day of the previous New Moon
        using Meeus Ch. 49 mean phase formula.
        Accuracy: ±2 minutes.
        """
        # Number of synodic months since 2000 Jan 6 18:14 UT
        k = int((jd_now - 2451550.09765) / self.SYNODIC_MONTH)

        T = k / 1236.85
        T2 = T * T
        T3 = T2 * T
        T4 = T3 * T

        # Meeus mean new moon
        jd = (
            2451550.09765
            + self.SYNODIC_MONTH * k
            + 0.0001337 * T2
            - 0.000000150 * T3
            + 0.00000000073 * T4
        )

        return jd

    def get_moon_age_days(self, jd_now):
        """
        Returns the true Moon age in days using Meeus Ch. 49
        with full NASA corrections.
        Accuracy: ±0.01 days.
        """

        # 1. Laske synodisen kuukauden numero (k)
        k = round((jd_now - 2451550.09765) / self.SYNODIC_MONTH)

        # 2. Laske T
        T = k / 1236.85
        T2 = T*T
        T3 = T2*T
        T4 = T3*T

        # 3. Mean New Moon (Meeus 49.1)
        jd_mean = (
            2451550.09765
            + self.SYNODIC_MONTH * k
            + 0.0001337 * T2
            - 0.000000150 * T3
            + 0.00000000073 * T4
        )

        # 4. Sun anomaly (M), Moon anomaly (M'), argument of latitude (F)
        M  = (2.5534 + 29.10535670 * k - 0.0000014*T2 - 0.00000011*T3) % 360
        M1 = (201.5643 + 385.81693528 * k + 0.0107582*T2 + 0.00001238*T3 - 0.000000058*T4) % 360
        F  = (160.7108 + 390.67050274 * k - 0.0016118*T2 - 0.00000227*T3 + 0.000000011*T4) % 360

        # 5. True New Moon correction (Meeus 49.3)
        corr = (
            -0.40720 * sin(radians(M1))
            + 0.17241 * sin(radians(M))
            + 0.01608 * sin(radians(2*M1))
            + 0.01039 * sin(radians(2*F))
            + 0.00739 * sin(radians(M1 - M))
            - 0.00514 * sin(radians(M1 + M))
            + 0.00208 * sin(radians(2*M))
            - 0.00111 * sin(radians(M1 - 2*F))
            - 0.00057 * sin(radians(M1 + 2*F))
            + 0.00056 * sin(radians(2*M1 + M))
            - 0.00042 * sin(radians(3*M1))
            + 0.00042 * sin(radians(M + 2*F))
            + 0.00038 * sin(radians(M - 2*F))
            - 0.00024 * sin(radians(2*M1 - M))
            - 0.00017 * sin(radians(F))
            - 0.00007 * sin(radians(M1 + 2*M))
            + 0.00004 * sin(radians(2*M1 - 2*F))
            + 0.00004 * sin(radians(3*M))
            + 0.00003 * sin(radians(M1 + M - 2*F))
            + 0.00003 * sin(radians(2*M1 + 2*F))
            - 0.00003 * sin(radians(M1 + M + 2*F))
            + 0.00003 * sin(radians(M1 - M + 2*F))
        )

        jd_true_newmoon = jd_mean + corr

        # 6. Jos tämä uusi kuu on tulevaisuudessa → ota edellinen
        if jd_true_newmoon > jd_now:
            jd_true_newmoon -= self.SYNODIC_MONTH
        # print("DEBUG jd_now:", jd_now)
        # print("DEBUG jd_true_newmoon:", jd_true_newmoon)
        # print("DEBUG age_days:", jd_now - jd_true_newmoon)

        # 7. Kuun ikä päivinä
        return jd_now - jd_true_newmoon

    def get_moon_age_from_api(self):
        """
        Returns Moon age in days using USNO API true new moon time.
        Accuracy: ±0.01 days.
        """
        if not self.api_data:
            return None

        closest = self.api_data.get("closestphase")
        if not closest:
            return None

        date_str = closest.get("date")
        time_str = closest.get("time")
        if not date_str or not time_str:
            return None

        # Parse new moon datetime (local time)
        dt_newmoon = datetime.datetime.strptime(
            date_str + " " + time_str, "%Y-%m-%d %H:%M"
        )

        # Convert to JD
        jd_newmoon = self._date_to_jd(dt_newmoon)

        # Current JD
        jd_now = self._get_julian_day()

        # Age
        age = jd_now - jd_newmoon
        if age < 0:
            age += self.SYNODIC_MONTH

        return age

    def get_moon_ra_dec(self, jd):
        """
        Palauttaa Kuun rektaskension (rad) ja deklinaation (rad) annetulla JD:llä.
        Riittää kulminaatioajan laskentaan.
        """
        T = (jd - 2451545.0) / 36525.0

        # Meeus: karkea mutta hyvä RA/Dec-malli
        L0 = radians((218.3164477 + 481267.88123421 * T) % 360.0)
        M  = radians((134.9633964 + 477198.8675055 * T) % 360.0)
        F  = radians((93.2720950  + 483202.0175233 * T) % 360.0)

        # Ekliptinen pituus ja leveys
        lon = L0 + radians(6.289) * sin(M)
        lat = radians(5.128) * sin(F)

        # Obliquity
        eps = radians(23.439291 - 0.0130042 * T)

        # Ekliptinen → ekvaattorikoordinaatit
        ra = atan2(
            sin(lon) * cos(eps) - tan(lat) * sin(eps),
            cos(lon)
        )
        dec = asin(
            sin(lat) * cos(eps) + cos(lat) * sin(eps) * sin(lon)
        )

        return ra, dec

    def get_moon_transit_time(self, jd, longitude_deg):
        """
        Kuun yläkulminaatio (JD) annetulle päivälle ja pituuspiirille.
        jd: päivän 0h UT (tai lähellä sitä).
        longitude_deg: itäinen pituus +, läntinen -.
        Palauttaa ajan UTC:na (JD).
        """

        # 1) Päivän 0h UT
        jd0 = int(jd - 0.5) + 0.5

        # 2) GMST klo 0 UT (Meeus 12.4)
        T = (jd0 - 2451545.0) / 36525.0
        theta0 = (
            280.46061837
            + 360.98564736629 * (jd0 - 2451545.0)
            + 0.000387933 * T * T
            - T * T * T / 38710000.0
        ) % 360.0

        # 3) Alkuarvaus: UT ≈ 12 h
        UT = 12.0

        # 4) Newton-iterointi (3–4 kierrosta riittää)
        for _ in range(4):
            jd_guess = jd0 + UT / 24.0
            ra, _ = self.get_moon_ra_dec(jd_guess)
            ra_deg = (degrees(ra) + 360.0) % 360.0

            # Tuntikulma H (astetta), Meeus 15.1
            H = (
                theta0
                + 1.00273790935 * 15.0 * UT
                + longitude_deg
                - ra_deg
            )
            H = (H + 540.0) % 360.0 - 180.0  # -180…+180

            # Newton-askel: ratkaistaan H = 0
            UT -= H / (1.00273790935 * 15.0)

        # 5) Palauta kulminaatiohetki JD-muodossa (UTC)
        transit_jd = jd0 + UT / 24.0
        return transit_jd