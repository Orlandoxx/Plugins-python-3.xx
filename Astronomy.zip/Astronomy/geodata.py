#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Geodata
#
# Evg77734 2024 (c)
#

import os
import sys
import json

path = "/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/ip.js"

def getdata():
	n = []
	c = []
	u = {}
	try:
		if os.path.exists(path) == True:
			with open(path, "r") as data_file:
				data = json.load(data_file)
				n.append(data['latitude'])
				n.append(data['longitude'])
				n.append(data['timezone'])
				c.append(n[0])
				c.append(n[1])
				u = n[2]
				u1 = u.get('utc')
				u2 = int(u1.split(':')[0])
				c.append(u2)
		else:
			os.system("wget -qO- \'http://ipwho.is/?output=json&fields=latitude,longitude,timezone.utc\' -O " + str(path))

			if os.path.exists(path) == True:
				with open(path, "r") as data_file:
					data = json.load(data_file)
					n.append(data['latitude'])
					n.append(data['longitude'])
					n.append(data['timezone'])
					c.append(n[0])
					c.append(n[1])
					u = n[2]
					u1 = u.get('utc')
					u2 = int(u1.split(':')[0])
					c.append(u2)
	except:
		n = [37.0,58.0,3]
		c = n

	return c
