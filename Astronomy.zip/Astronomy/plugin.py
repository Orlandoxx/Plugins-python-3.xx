#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Astronomy
#
# Copyright 2023 Evg77734
# modified by Orlandox
#

from Components.config import config, getConfigListEntry, ConfigSelection, ConfigSubsection, ConfigYesNo, configfile, NoSave
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from Components.ActionMap import NumberActionMap, ActionMap
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from Components.Language import language
from enigma import eTimer, ePoint, eSize
from os import environ, system, popen
from Components.Pixmap import Pixmap
from Components.Label import Label
from Screens.Screen import Screen
from threading import Thread
from .geodata import getdata
from .astro import astro
import gettext
import time
import math
import os

ver = '1.2.1'

global azmoon, azmercury, azvenus, azmars, azjupiter, azsaturn, azuranus, azneptune, intertval
azmoon = 0
azmercury = 0
azvenus = 0
azmars = 0
azjupiter = 0
azsaturn = 0
azuranus = 0
azneptune = 0
intertval = 1000

mygeo = []
mygeo = getdata()
latitude = mygeo[0]
longitude = mygeo[1]
timezone = mygeo[2]
#latitude = "00.00"
#longitude = "00.00"
#timezone = "0"

lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("Astronomy", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/Astronomy/locale/"))

def _(txt):
	t = gettext.dgettext("Astronomy", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

class Astronomy(Screen):
	skin = """
<screen name="Astronomy" position="0,0" size="1920,1080" zPosition="0" flags="wfNoBorder" transparent="0">
  <ePixmap name="" position="0, 0" size="1920,1080" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/fon.png" />
  <ePixmap name="" position="840,0" size="1080,1080" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/orbit.png" alphatest="on" />
  <ePixmap name="" position="850,20" size="42,42" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/longitude.png" alphatest="on" />
  <ePixmap name="" position="850,70" size="42,42" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/latitude.png" alphatest="on" />
  <ePixmap name="" position="850,120" size="42,42" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/timezone.png" alphatest="on" />
  <widget name="red_key" position="1550,996" zPosition="2" size="350,38" font="Regular; 28" halign="right" valign="center" backgroundColor="#41000000" foregroundColor="#dddddd" transparent="1" />
  <widget name="moon" position="1852,130" size="40,40" zPosition="3" alphatest="blend" transparent="0" />
  <widget name="earth" position="1852,170" size="40,40" zPosition="3" alphatest="blend" transparent="0" />
  <widget name="mercury" position="1852,210" size="40,40" zPosition="3" alphatest="blend" transparent="0" />
  <widget name="venus" position="1852,250" size="40,40" zPosition="3" alphatest="blend" transparent="0" />
  <widget name="mars" position="1852,290" size="40,40" zPosition="3" alphatest="blend" transparent="0" />
  <widget name="jupiter" position="1852,340" size="40,40" zPosition="3" alphatest="blend" transparent="0" />
  <widget name="saturn" position="1852,380" size="40,40" zPosition="3" alphatest="blend" transparent="0" />
  <widget name="uranus" position="1852,420" size="40,40" zPosition="3" alphatest="blend" transparent="0" />
  <widget name="neptune" position="1852,460" size="40,40" zPosition="3" alphatest="blend" transparent="0" />
  <widget name="moon1" position="50,106" size="90,90" zPosition="1" alphatest="blend" transparent="0" />
  <ePixmap name="" position="50,370" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mercury1.png" alphatest="blend" />
  <widget name="Planet1" position="30,360" size="130,30" font="Regular;20" zPosition="3" alphatest="on" transparent="1" halign="center" />
  <ePixmap name="" position="50,470" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/venus1.png" alphatest="blend" />
  <widget name="Planet2" position="30,460" size="130,30" font="Regular;20" zPosition="3" alphatest="on" transparent="1" halign="center" />
  <ePixmap name="" position="50,570" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mars1.png" alphatest="blend" />
  <widget name="Planet3" position="30,560" size="130,30" font="Regular;20" zPosition="3" alphatest="on" transparent="1" halign="center" />
  <ePixmap name="" position="50,670" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/jupiter1.png" alphatest="blend" />
  <widget name="Planet4" position="30,660" size="130,30" font="Regular;20" zPosition="3" alphatest="on" transparent="1" halign="center" />
  <ePixmap name="" position="50,770" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/saturn1.png" alphatest="blend" />
  <widget name="Planet5" position="30,760" size="130,30" font="Regular;20" zPosition="3" alphatest="on" transparent="1" halign="center" />
  <ePixmap name="" position="50,870" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/uranus1.png" alphatest="blend" />
  <widget name="Planet6" position="30,860" size="130,30" font="Regular;20" zPosition="3" alphatest="on" transparent="1" halign="center" />
  <ePixmap name="" position="50,970" size="90,90" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/neptune1.png" alphatest="blend" />
  <widget name="Planet7" position="30,960" size="130,30" font="Regular;20" zPosition="3" alphatest="on" transparent="1" halign="center" />
  <widget name="longitude" position="910,20" size="250,42" zPosition="2" font="Regular;32" transparent="1" />
  <widget name="latitude" position="910,70" size="250,42" zPosition="2" font="Regular;32" transparent="1" />
  <widget name="timezone" position="910,120" size="80,42" zPosition="2" font="Regular;32" transparent="1" />
  <widget name="sunrise" position="1780,10" size="120,42" zPosition="2" font="Regular;32" transparent="1" />
  <widget name="sunset" position="1780,151" size="120,42" zPosition="2" font="Regular;32" transparent="1" />
  <widget name="suncul" position="1780,55" size="125,26" zPosition="2" font="Regular;22" transparent="1" />
  <widget name="sunculmination" position="1780,81" size="120,42" zPosition="2" font="Regular;32" transparent="1" />
  <ePixmap name="" position="1715,22" size="61,155" zPosition="2" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/sunrsc.png" />
  <widget name="JulianDay" position="164,250" size="300,40" font="Regular;28" zPosition="3" alphatest="on" transparent="1" />
  <widget name="jd" position="494,250" size="350,38" zPosition="2" font="Regular; 28" transparent="1" />
  <widget name="mercury1" position="150,394" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="mercury2" position="280,394" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="mercury3" position="410,394" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="mercury4" position="540,394" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="mercury5" position="670,394" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="venus1" position="150,494" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="venus2" position="280,494" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="venus3" position="410,494" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="venus4" position="540,494" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="venus5" position="670,494" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="mars1" position="150,594" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="mars2" position="280,594" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="mars3" position="410,594" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="mars4" position="540,594" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="mars5" position="670,594" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="jupiter1" position="150,694" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="jupiter2" position="280,694" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="jupiter3" position="410,694" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="jupiter4" position="540,694" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="jupiter5" position="670,694" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="saturn1" position="150,794" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="saturn2" position="280,794" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="saturn3" position="410,794" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="saturn4" position="540,794" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="saturn5" position="670,794" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="uranus1" position="150,894" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="uranus2" position="280,894" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="uranus3" position="410,894" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="uranus4" position="540,894" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="uranus5" position="670,894" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="neptune1" position="150,994" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="neptune2" position="280,994" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="neptune3" position="410,994" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="neptune4" position="540,994" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="neptune5" position="670,994" size="105,42" zPosition="1" font="Regular;32" transparent="1" />
  <widget name="moon11" position="369,55" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
  <widget name="moon12" position="369,105" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
  <widget name="moon13" position="369,155" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
  <widget name="moon14" position="369,205" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
  <widget name="moon15" position="634,55" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
  <widget name="moon16" position="634,105" size="200,42" zPosition="1" font="Regular;28" transparent="1" />
  <widget name="moon17" position="634,155" size="100,42" zPosition="1" font="Regular;28" transparent="1" />
  <widget name="moon18" position="634,207" size="370,42" zPosition="1" font="Regular;28" transparent="1" />
  <widget name="txt1" position="125,320" size="125,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
  <widget name="txt2" position="255,320" size="125,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
  <widget name="txt3" position="385,320" size="125,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
  <widget name="txt4" position="515,320" size="125,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
  <widget name="txt5" position="645,320" size="125,84" zPosition="1" font="Regular;26" transparent="1" halign="center" />
  <widget name="txtmoon11" position="164,55" size="200,42" zPosition="1" font="Regular;26" transparent="1" />
  <widget name="txtmoon12" position="164,105" size="200,42" zPosition="1" font="Regular;26" transparent="1" />
  <widget name="txtmoon13" position="164,155" size="200,42" zPosition="1" font="Regular;26" transparent="1" />
  <widget name="txtmoon14" position="164,205" size="200,42" zPosition="1" font="Regular;26" transparent="1" />
  <widget name="txtmoon15" position="494,55" size="135,42" zPosition="1" font="Regular;26" transparent="1" />
  <widget name="txtmoon16" position="494,105" size="135,42" zPosition="1" font="Regular;26" transparent="1" />
  <widget name="txtmoon17" position="494,155" size="135,42" zPosition="1" font="Regular;26" transparent="1" />
  <widget name="txtmoon18" position="494,205" size="135,42" zPosition="1" font="Regular;26" transparent="1" />
  <widget name="eye0" position="785,59" size="33,33" zPosition="2" alphatest="on" transparent="0" />
  <widget name="eye1" position="785,398" size="33,33" zPosition="2" alphatest="on" transparent="0" />
  <widget name="eye2" position="785,498" size="33,33" zPosition="2" alphatest="on" transparent="0" />
  <widget name="eye3" position="785,598" size="33,33" zPosition="2" alphatest="on" transparent="0" />
  <widget name="eye4" position="785,698" size="33,33" zPosition="2" alphatest="on" transparent="0" />
  <widget name="eye5" position="785,798" size="33,33" zPosition="2" alphatest="on" transparent="0" />
  <widget name="eye6" position="785,898" size="33,33" zPosition="2" alphatest="on" transparent="0" />
  <widget name="eye7" position="785,998" size="33,33" zPosition="2" alphatest="on" transparent="0" />
  <ePixmap name="" position="995,1030" size="61,44" zPosition="2" alphatest="blend" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/key_info.png" />
  <widget name="last" position="0,0" size="0,0" />
</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)

		self["red_key"] = Label("\"Astronomy\" ver. " + str(ver))
		self["last"] = Label(_("n/a"))
		self["moon"] = Pixmap()
		self["moon1"] = Pixmap()
		self["earth"] = Pixmap()
		self["mercury"] = Pixmap()
		self["venus"] = Pixmap()
		self["mars"] = Pixmap()
		self["jupiter"] = Pixmap()
		self["saturn"] = Pixmap()
		self["uranus"] = Pixmap()
		self["neptune"] = Pixmap()
		self["longitude"] = Label("n/a")
		self["latitude"] = Label("n/a")
		self["timezone"] = Label("n/a")
		self["sunrise"] = Label("n/a")
		self["sunset"] = Label("n/a")
		self["sunculmination"] = Label("n/a")
		self["JulianDay"] = Label(_("Julian Day"))
		self["Planet1"] = Label(_("Mercury"))
		self["Planet2"] = Label(_("Venus"))
		self["Planet3"] = Label(_("Mars"))
		self["Planet4"] = Label(_("Jupiter"))
		self["Planet5"] = Label(_("Saturn"))
		self["Planet6"] = Label(_("Uranus"))
		self["Planet7"] = Label(_("Neptune"))
		self["jd"] = Label("n/a")
		self["mercury1"] = Label("n/a")
		self["mercury2"] = Label("n/a")
		self["mercury3"] = Label("n/a")
		self["mercury4"] = Label("n/a")
		self["mercury5"] = Label("n/a")
		self["venus1"] = Label("n/a")
		self["venus2"] = Label("n/a")
		self["venus3"] = Label("n/a")
		self["venus4"] = Label("n/a")
		self["venus5"] = Label("n/a")
		self["mars1"] = Label("n/a")
		self["mars2"] = Label("n/a")
		self["mars3"] = Label("n/a")
		self["mars4"] = Label("n/a")
		self["mars5"] = Label("n/a")
		self["jupiter1"] = Label("n/a")
		self["jupiter2"] = Label("n/a")
		self["jupiter3"] = Label("n/a")
		self["jupiter4"] = Label("n/a")
		self["jupiter5"] = Label("n/a")
		self["saturn1"] = Label("n/a")
		self["saturn2"] = Label("n/a")
		self["saturn3"] = Label("n/a")
		self["saturn4"] = Label("n/a")
		self["saturn5"] = Label("n/a")
		self["uranus1"] = Label("n/a")
		self["uranus2"] = Label("n/a")
		self["uranus3"] = Label("n/a")
		self["uranus4"] = Label("n/a")
		self["uranus5"] = Label("n/a")
		self["neptune1"] = Label("n/a")
		self["neptune2"] = Label("n/a")
		self["neptune3"] = Label("n/a")
		self["neptune4"] = Label("n/a")
		self["neptune5"] = Label("n/a")
		self["moon11"] = Label("n/a")
		self["moon12"] = Label("n/a")
		self["moon13"] = Label("n/a")
		self["moon14"] = Label("n/a")
		self["moon15"] = Label("n/a")
		self["moon16"] = Label("n/a")
		self["moon17"] = Label("n/a")
		self["moon18"] = Label("n/a")
		self["txt1"] = Label(_('Rise'))
		self["txt2"] = Label(_('Set'))
		self["txt3"] = Label(_("Culmination"))
		self["txt4"] = Label(_("Azimuth"))
		self["txt5"] = Label(_("Height"))
		self["txtmoon11"] = Label(_("Rise"))
		self["txtmoon12"] = Label(_("Set"))
		self["txtmoon13"] = Label(_("Culmination"))
		self["txtmoon14"] = Label(_("Azimuth"))
		self["txtmoon15"] = Label(_("Height"))
		self["txtmoon16"] = Label(_("Distance"))
		self["txtmoon17"] = Label(_("Light"))
		self["txtmoon18"] = Label(_("Phase"))
		self["eye0"] = Pixmap()
		self["eye1"] = Pixmap()
		self["eye2"] = Pixmap()
		self["eye3"] = Pixmap()
		self["eye4"] = Pixmap()
		self["eye5"] = Pixmap()
		self["eye6"] = Pixmap()
		self["eye7"] = Pixmap()
		self["suncul"] = Label(_("Culmination"))

		self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions", "ColorActions", "NumberActions", 'EPGSelectActions'],
		{
			"cancel": self.cancel,
			"back": self.cancel,
			'info': self.infoKey,
			"red": self.cancel
			})

		self.onShow.append(self.show1)

	def show1(self):
		self["moon"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/moon.png")
		self["moon"].move(ePoint(1360, 460))
		self["moon"].instance.show()
		self["earth"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/earth.png")
		self["earth"].move(ePoint(1360, 520))
		self["earth"].instance.show()
		self["mercury"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mercury.png")
		self["mercury"].move(ePoint(1360, 400))
		self["mercury"].instance.show()
		self["venus"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/venus.png")
		self["venus"].move(ePoint(1360, 340))
		self["venus"].instance.show()
		self["mars"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/mars.png")
		self["mars"].move(ePoint(1360, 280))
		self["mars"].instance.show()
		self["jupiter"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/jupiter.png")
		self["jupiter"].move(ePoint(1360, 220))
		self["jupiter"].instance.show()
		self["saturn"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/saturn.png")
		self["saturn"].move(ePoint(1360, 160))
		self["saturn"].instance.show()
		self["uranus"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/uranus.png")
		self["uranus"].move(ePoint(1360, 100))
		self["uranus"].instance.show()
		self["neptune"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/planet/neptune.png")
		self["neptune"].move(ePoint(1360, 40))
		self["neptune"].instance.show()
		self["moon1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/moon/100.png")
		self["moon1"].instance.show()

		self["eye0"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
		self["eye0"].instance.hide()
		self["eye1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
		self["eye1"].instance.hide()
		self["eye2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
		self["eye2"].instance.hide()
		self["eye3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
		self["eye3"].instance.hide()
		self["eye4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
		self["eye4"].instance.hide()
		self["eye5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
		self["eye5"].instance.hide()
		self["eye6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
		self["eye6"].instance.hide()
		self["eye7"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
		self["eye7"].instance.hide()
	

		Thread0 = Thread(target=self.basis)
		Thread0.start()
		Thread1 = Thread(target=self.moonrotation)
		Thread1.start()
		Thread2 = Thread(target=self.mercuryrotation)
		Thread2.start()
		Thread3 = Thread(target=self.venusrotation)
		Thread3.start()
		Thread4 = Thread(target=self.marsrotation)
		Thread4.start()
		Thread5 = Thread(target=self.jupiterrotation)
		Thread5.start()
		Thread6 = Thread(target=self.saturnrotation)
		Thread6.start()
		Thread7 = Thread(target=self.uranusrotation)
		Thread7.start()
		Thread8 = Thread(target=self.neptunerotation)
		Thread8.start()

	def basis(self):
		self.moveTimer0 = eTimer()
		self.moveTimer0.callback.append(self.start)
		self.moveTimer0.start(100, 1)

	def neptunerotation(self):
		self.moveTimer8 = eTimer()
		self.moveTimer8.callback.append(self.neptunedata)
		self.moveTimer8.start(100, 1)

	def neptunedata(self):
		global azneptune, intertval
		self.moveTimer8.start(intertval, 1)
		x1 = 1360
		y1 = 520
		D = 480
		x2 = x1 + math.cos(float(azneptune - 90)*3.14159265359/180)*D
		y2 = y1 + math.sin(float(azneptune - 90)*3.14159265359/180)*D
		self["neptune"].move(ePoint(int(x2), int(y2)))
		azneptune = azneptune + 1
		if azneptune == 360:
			azneptune = 0

	def uranusrotation(self):
		self.moveTimer7 = eTimer()
		self.moveTimer7.callback.append(self.uranusdata)
		self.moveTimer7.start(100, 1)

	def uranusdata(self):
		global azuranus, intertval
		self.moveTimer7.start(intertval, 1)
		x1 = 1360
		y1 = 520
		D = 420
		x2 = x1 + math.cos(float(azuranus - 90)*3.14159265359/180)*D
		y2 = y1 + math.sin(float(azuranus - 90)*3.14159265359/180)*D
		self["uranus"].move(ePoint(int(x2), int(y2)))
		azuranus = azuranus + 1
		if azuranus == 360:
			azuranus = 0

	def saturnrotation(self):
		self.moveTimer6 = eTimer()
		self.moveTimer6.callback.append(self.saturndata)
		self.moveTimer6.start(100, 1)

	def saturndata(self):
		global azsaturn, intertval
		self.moveTimer6.start(intertval, 1)
		x1 = 1360
		y1 = 520
		D = 360
		x2 = x1 + math.cos(float(azsaturn - 90)*3.14159265359/180)*D
		y2 = y1 + math.sin(float(azsaturn - 90)*3.14159265359/180)*D
		self["saturn"].move(ePoint(int(x2), int(y2)))
		azsaturn = azsaturn + 1
		if azsaturn == 360:
			azsaturn = 0

	def jupiterrotation(self):
		self.moveTimer5 = eTimer()
		self.moveTimer5.callback.append(self.jupiterdata)
		self.moveTimer5.start(100, 1)

	def jupiterdata(self):
		global azjupiter, intertval
		self.moveTimer5.start(intertval, 1)
		x1 = 1360
		y1 = 520
		D = 300
		x2 = x1 + math.cos(float(azjupiter - 90)*3.14159265359/180)*D
		y2 = y1 + math.sin(float(azjupiter - 90)*3.14159265359/180)*D
		self["jupiter"].move(ePoint(int(x2), int(y2)))
		azjupiter = azjupiter + 1
		if azjupiter == 360:
			azjupiter = 0

	def marsrotation(self):
		self.moveTimer4 = eTimer()
		self.moveTimer4.callback.append(self.marsdata)
		self.moveTimer4.start(100, 1)

	def marsdata(self):
		global azmars,intertval
		self.moveTimer4.start(intertval, 1)
		x1 = 1360
		y1 = 520
		D = 240
		x2 = x1 + math.cos(float(azmars - 90)*3.14159265359/180)*D
		y2 = y1 + math.sin(float(azmars - 90)*3.14159265359/180)*D
		self["mars"].move(ePoint(int(x2), int(y2)))
		azmars = azmars + 1
		if azmars == 360:
			azmars = 0

	def venusrotation(self):
		self.moveTimer3 = eTimer()
		self.moveTimer3.callback.append(self.venusdata)
		self.moveTimer3.start(100, 1)

	def venusdata(self):
		global azvenus, intertval
		self.moveTimer3.start(intertval, 1)
		x1 = 1360
		y1 = 520
		D = 180
		x2 = x1 + math.cos(float(azvenus - 90)*3.14159265359/180)*D
		y2 = y1 + math.sin(float(azvenus - 90)*3.14159265359/180)*D
		self["venus"].move(ePoint(int(x2), int(y2)))
		azvenus = azvenus + 1
		if azvenus == 360:
			azvenus = 0

	def mercuryrotation(self):
		self.moveTimer2 = eTimer()
		self.moveTimer2.callback.append(self.mercurydata)
		self.moveTimer2.start(100, 1)

	def mercurydata(self):
		global azmercury, intertval
		self.moveTimer2.start(intertval, 1)
		x1 = 1360
		y1 = 520
		D = 120
		x2 = x1 + math.cos(float(azmercury - 90)*3.14159265359/180)*D
		y2 = y1 + math.sin(float(azmercury - 90)*3.14159265359/180)*D
		self["mercury"].move(ePoint(int(x2), int(y2)))
		azmercury = azmercury + 1
		if azmercury == 360:
			azmercury = 0

	def moonrotation(self):
		self.moveTimer1 = eTimer()
		self.moveTimer1.callback.append(self.moondata)
		self.moveTimer1.start(100, 1)

	def moondata(self):
		global azmoon, intertval
		self.moveTimer1.start(intertval, 1)
		x1moon = 1360
		y1moon = 520
		D = 60
		x2moon = x1moon + math.cos(float(azmoon - 90)*3.14159265359/180)*D
		y2moon = y1moon + math.sin(float(azmoon - 90)*3.14159265359/180)*D
		self["moon"].move(ePoint(int(x2moon), int(y2moon)))
		azmoon = azmoon + 1
		if azmoon == 360:
			azmoon = 0

	def start(self):
		global azmercury, azvenus, azmars, azjupiter, azsaturn, azuranus, azneptune, azmoon, intertval
		self.moveTimer0.start(intertval, 1)

		allplanets = []
		allplanets = astro(longitude, latitude, timezone)
		pimoon = allplanets[2][7].split(' ')[1]
		self["moon1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/moon/" + str(pimoon) + ".png")
		self["moon1"].instance.show()
		
		self["longitude"].setText(str(allplanets[0][0].split(' ')[1]) + '\xb0')
		self["latitude"].setText(str(allplanets[0][1].split(' ')[1]) + '\xb0')
		tz = int(allplanets[0][2].split(' ')[1])
		if tz > 0:
			tz = '+' + str(tz)
		self["timezone"].setText(str(tz))

		self["sunrise"].setText(str(allplanets[1][1].split(' ')[2]))
		self["sunset"].setText(str(allplanets[1][2].split(' ')[2]))
		self["sunculmination"].setText(str(allplanets[1][3].split(' ')[2]))
		self["jd"].setText(str(allplanets[1][0].split(' ')[2]))
		
		self["mercury1"].setText(str(allplanets[3][0].split(' ')[2]))
		self["mercury2"].setText(str(allplanets[3][1].split(' ')[2]))
		self["mercury3"].setText(str(allplanets[3][2].split(' ')[2]))
		azmercury = int(float(allplanets[3][3].split(' ')[2]))
		self["mercury4"].setText(str(allplanets[3][3].split(' ')[2]) + '\xb0')
		self["mercury5"].setText(str(allplanets[3][4].split(' ')[2]) + '\xb0')
		if float(allplanets[3][4].split(' ')[2]) >= 0:
			self["eye1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
			self["eye1"].instance.show()
		else:
			self["eye1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
			self["eye1"].instance.show()

		self["venus1"].setText(str(allplanets[4][0].split(' ')[2]))
		self["venus2"].setText(str(allplanets[4][1].split(' ')[2]))
		self["venus3"].setText(str(allplanets[4][2].split(' ')[2]))
		azvenus = int(float(allplanets[4][3].split(' ')[2]))
		self["venus4"].setText(str(allplanets[4][3].split(' ')[2]) + '\xb0')
		self["venus5"].setText(str(allplanets[4][4].split(' ')[2]) + '\xb0')
		if float(allplanets[4][4].split(' ')[2]) >= 0:
			self["eye2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
			self["eye2"].instance.show()
		else:
			self["eye2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
			self["eye2"].instance.show()

		self["mars1"].setText(str(allplanets[5][0].split(' ')[2]))
		self["mars2"].setText(str(allplanets[5][1].split(' ')[2]))
		self["mars3"].setText(str(allplanets[5][2].split(' ')[2]))
		azmars = int(float(allplanets[5][3].split(' ')[2]))
		self["mars4"].setText(str(allplanets[5][3].split(' ')[2]) + '\xb0')
		self["mars5"].setText(str(allplanets[5][4].split(' ')[2]) + '\xb0')
		if float(allplanets[5][4].split(' ')[2]) >= 0:
			self["eye3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
			self["eye3"].instance.show()
		else:
			self["eye3"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
			self["eye3"].instance.show()

		self["jupiter1"].setText(str(allplanets[6][0].split(' ')[2]))
		self["jupiter2"].setText(str(allplanets[6][1].split(' ')[2]))
		self["jupiter3"].setText(str(allplanets[6][2].split(' ')[2]))
		azjupiter = int(float(allplanets[6][3].split(' ')[2]))
		self["jupiter4"].setText(str(allplanets[6][3].split(' ')[2]) + '\xb0')
		self["jupiter5"].setText(str(allplanets[6][4].split(' ')[2]) + '\xb0')
		if float(allplanets[6][4].split(' ')[2]) >= 0:
			self["eye4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
			self["eye4"].instance.show()
		else:
			self["eye4"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
			self["eye4"].instance.show()

		self["saturn1"].setText(str(allplanets[7][0].split(' ')[2]))
		self["saturn2"].setText(str(allplanets[7][1].split(' ')[2]))
		self["saturn3"].setText(str(allplanets[7][2].split(' ')[2]))
		azsaturn = int(float(allplanets[7][3].split(' ')[2]))
		self["saturn4"].setText(str(allplanets[7][3].split(' ')[2]) + '\xb0')
		self["saturn5"].setText(str(allplanets[7][4].split(' ')[2]) + '\xb0')
		if float(allplanets[7][4].split(' ')[2]) >= 0:
			self["eye5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
			self["eye5"].instance.show()
		else:
			self["eye5"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
			self["eye5"].instance.show()

		self["uranus1"].setText(str(allplanets[8][0].split(' ')[2]))
		self["uranus2"].setText(str(allplanets[8][1].split(' ')[2]))
		self["uranus3"].setText(str(allplanets[8][2].split(' ')[2]))
		azuranus = int(float(allplanets[8][3].split(' ')[2]))
		self["uranus4"].setText(str(allplanets[8][3].split(' ')[2]) + '\xb0')
		self["uranus5"].setText(str(allplanets[8][4].split(' ')[2]) + '\xb0')
		if float(allplanets[8][4].split(' ')[2]) >= 0:
			self["eye6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
			self["eye6"].instance.show()
		else:
			self["eye6"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
			self["eye6"].instance.show()

		self["neptune1"].setText(str(allplanets[9][0].split(' ')[2]))
		self["neptune2"].setText(str(allplanets[9][1].split(' ')[2]))
		self["neptune3"].setText(str(allplanets[9][2].split(' ')[2]))
		azneptune = int(float(allplanets[9][3].split(' ')[2]))
		self["neptune4"].setText(str(allplanets[9][3].split(' ')[2]) + '\xb0')
		self["neptune5"].setText(str(allplanets[9][4].split(' ')[2]) + '\xb0')
		if float(allplanets[9][4].split(' ')[2]) >= 0:
			self["eye7"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
			self["eye7"].instance.show()
		else:
			self["eye7"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
			self["eye7"].instance.show()

		self["moon11"].setText(str(allplanets[2][2].split(' ')[2]))
		self["moon12"].setText(str(allplanets[2][3].split(' ')[2]))
		self["moon13"].setText(str(allplanets[2][4].split(' ')[2]))
		azmoon = int(float(allplanets[2][1].split(' ')[2]))
		self["moon14"].setText(str(allplanets[2][1].split(' ')[2]) + '\xb0')
		self["moon15"].setText(str(allplanets[2][8].split(' ')[2]) + '\xb0')
		self["moon16"].setText(str(allplanets[2][0].split(' ')[1]) + _(' km'))
		self["moon17"].setText(str(allplanets[2][6].split(' ')[2]))
		self["moon18"].setText(str(_(allplanets[2][5].split(' ')[2] + ' ' + allplanets[2][5].split(' ')[3])))
		if float(allplanets[2][8].split(' ')[2]) >= 0:
			self["eye0"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeon.png")
			self["eye0"].instance.show()
		else:
			self["eye0"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/eyeoff.png")
			self["eye0"].instance.show()

	def cancel(self):
		global azmoon, azmercury, azvenus, azmars, azjupiter, azsaturn, azuranus, azneptune
		azmoon = 0
		azmercury = 0
		azvenus = 0
		azmars = 0
		azjupiter = 0
		azsaturn = 0
		azuranus = 0
		azneptune = 0
		self.close()

	def infoKey (self):
		self.session.open(InfoBox1)

class InfoBox1(Screen):
	skin = """<screen name="AboutAstronomy" position="480,309" flags="wfNoBorder" transparent="0" backgroundColor="Background" size="960,462">
	<ePixmap name="" position="0, 0" size="960,462" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Astronomy/images/infobox.png" />
	<widget name="" position="45,140" size="880,42" zPosition="1" font="Regular; 32" source="ver" render="Label" transparent="1" halign="center" />
	<eLabel name="" position="230,220" size="500,42" zPosition="1" font="Regular; 32" text="Idea and calculations: Sirius" transparent="1" halign="center" />
	<eLabel name="" position="280,295" size="400,42" zPosition="1" font="Regular; 32" text="Developer: Evg77734" transparent="1" halign="center" />
	<eLabel name="" position="280,370" size="400,42" zPosition="1" font="Regular; 32" text="Homepage: gisclub.tv" transparent="1" halign="center" />
	</screen>"""

	def __init__(self, session):

		Screen.__init__(self, session)

		self['ver'] = StaticText('Astronomy online  ver. ' + str(ver))

		self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions"],
		{
			"cancel": self.Exit,
			'ok': self.Exit,
		}, -1)

	def Exit(self):
		self.close()

def main(session, **kwargs):
	session.open(Astronomy)

def Plugins(path, **kwargs):
	return PluginDescriptor(name = _("Astronomy") + " ver. " + ver, where = [PluginDescriptor.WHERE_PLUGINMENU], description = _("Astronomy online"), icon = 'astronomy.png', fnc = main)
