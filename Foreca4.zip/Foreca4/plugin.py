#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
#  Foreca 4 Weather and Forecast
#
#  (C) Evg77734, 2025
#  modified by Orlandox 26.01.2026
#

from __future__ import absolute_import

# from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from Components.Sources.StaticText import StaticText
from Components.ActionMap import HelpableActionMap
from .google_translate_api import translate_text
from Tools.BoundFunction import boundFunction
from Screens.HelpMenu import HelpableScreen
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.Language import language
from Components.Sources.List import List
from Components.MenuList import MenuList
from Tools.LoadPixmap import LoadPixmap
from skin import parseColor
from Components.Pixmap import Pixmap
from enigma import getDesktop
from Components.Label import Label
from Screens.Screen import Screen
from sys import version_info
from threading import Thread
# from os.path import exists
from enigma import gRGB
from os import environ

from .forecast_weather import getPageF_F
from .cur_weather import getPageF
from .tt_weather import getPageTT
from .skin import (
    # Meteogram_Foreca4_HD
    About_Foreca4_FHD,
    About_Foreca4_HD,
    ColorSelect_FHD,
    ColorSelect_HD,
    ExtInfo_2_Foreca4_FHD,
    ExtInfo_2_Foreca4_HD,
    ExtInfo_Foreca4_FHD,
    ExtInfo_Foreca4_HD,
    ForecaPreview_4_FHD,
    ForecaPreview_4_HD,
    Meteogram_Foreca4_FHD,
    Meteogram_Foreca4_HD,
    Transparency_Foreca4_FHD,
    Transparency_Foreca4_HD,
)

import gettext
import six
import os


lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("Foreca4", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/Foreca4/locale/"))


def _(txt):
    t = gettext.dgettext("Foreca4", txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


VERSION = "1.3.5"
TARGET_LANG = "en"
BASEURL = "https://www.foreca.com/"

path_loc0 = '102643743/London-United-Kingdom              # Blue - Home
path_loc1 = '100650859/Kouvola-Finland'                   # Green - Favorite 1
path_loc2 = '100658225/Helsinki-Finland'                  # Yellow - Favorite 2

cur_wind_speed_recalc = 1
for_wind_speed_recalc = 1

global MAIN_PAGE_FF, myloc, MAIN_PAGE_F, town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, rgbmyr, rgbmyg, rgbmyb, lon, lat, sunrise, daylen, sunset, alpha, share_town0, f_day
myloc = 0
MAIN_PAGE_F = str(BASEURL) + path_loc0
town = ' n/a'
cur_temp = ' n/a'
fl_temp = ' n/a'
dewpoint = ' n/a'
pic = ' n/a'
wind = ' n/a'
wind_speed = ' n/a'
wind_gust = ' n/a'
rain_mm = ' n/a'
hum = ' n/a'
pressure = ' n/a'
country = ' n/a'
MAIN_PAGE_FF = str(BASEURL) + path_loc0 + '/hourly?day=0'
f_town = ' n/a'
f_date = []
f_time = []
f_symb = []
f_cur_temp = []
f_flike_temp = []
f_wind = []
f_wind_speed = []
f_precipitation = []
f_rel_hum = []
rgbmyr = 0
rgbmyg = 80
rgbmyb = 239
alpha = '#10000000'
share_town0 = ''
f_day = ' n/a'


def conv_alpha(insel):
    rez = ' n/a'
    if insel == "#90000000":
        rez = '56%'
    elif insel == "#80000000":
        rez = '50%'
    elif insel == "#70000000":
        rez = '44%'
    elif insel == "#60000000":
        rez = '38%'
    elif insel == "#50000000":
        rez = '31%'
    elif insel == "#40000000":
        rez = '25%'
    elif insel == "#30000000":
        rez = '19%'
    elif insel == "#20000000":
        rez = '13%'
    elif insel == "#10000000":
        rez = '6%'
    return rez


def trans(t):
    rez = t
    try:
        s = t
        translate_text_1 = translate_text(s, target_lang=TARGET_LANG)
        rez = translate_text_1
    except:
        rez = t
    return rez


def conv_day_len(indata):
    rez = indata
    try:
        inall = indata.split(' ')
        in2 = _(str(inall[1]))
        in3 = _(str(inall[3]))
        rez = inall[0] + ' ' + str(in2) + ' ' + inall[2] + ' ' + str(in3)
    except:
        rez = indata
    return rez


def mywindSpeed(indata, metka):
    try:
        rez = 0
        rez = '%.01f' % float(int(indata) / 3.6)
        if metka == 1:
            return float(rez)
        else:
            rez = '%.01f' % float(int(indata))
            return float(rez)
    except:
        return 0.00


size_w = getDesktop(0).size().width()
size_h = getDesktop(0).size().height()


class ForecaPreview_4(Screen, HelpableScreen):

    def __init__(self, session):
        global myloc, MAIN_PAGE_F, MAIN_PAGE_FF, town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, lon, lat, sunrise, daylen, sunset, share_town0, f_day
        self.session = session

        myloc = 0
        self.tag = 0

        MAIN_PAGE_F = str(BASEURL) + path_loc0
        town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, lon, lat, sunrise, daylen, sunset = getPageF(MAIN_PAGE_F)

        share_town0 = '  ' + _(str(town)) + ', ' + _(str(country))

        MAIN_PAGE_FF = str(BASEURL) + path_loc0 + '/hourly?day=0'
        f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, f_day = getPageF_F(MAIN_PAGE_FF)

        if size_w == 1920:
            self.skin = ForecaPreview_4_FHD
        else:
            self.skin = ForecaPreview_4_HD

        Screen.__init__(self, session)
        self.setTitle(_("Foreca Weather Forecast") + " " + _("v.") + VERSION)
        self.list = []
        self["menu"] = List(self.list)
        self["Titel"] = StaticText()
        self["mytitel2"] = StaticText()
        self["Titel2"] = StaticText(_("Please wait ..."))
        self["Titel3"] = StaticText()
        self["Titel5"] = StaticText()
        self["TitelOK"] = Label(_("Extra Info"))
        self["TitelHelp"] = Label(_("Help+"))
        self["TitelInfo"] = Label(_("Info"))
        self["TitelMenu"] = Label(_("Transparency"))
        self["TitelRed"] = Label(_("Color Select"))
        self["TitelGreen"] = Label(_("Fav. 1"))
        self["TitelYellow"] = Label(_("Fav. 2"))
        self["TitelBlue"] = Label(_("Home"))
        self["mytitel1"] = StaticText()
        self["town"] = Label('')
        self["cur_temp"] = Label('')
        self["fl_temp"] = Label('')
        self["dewpoint"] = Label('')
        self["pic"] = Pixmap()
        self["wind"] = Pixmap()
        self["wind_speed"] = Label('')
        self["wind_gust"] = Label('')
        self["rain_mm"] = Label('')
        self["hum"] = Label('')
        self["pressure"] = Label('')
        self["description_w"] = Label('')
        self["pressure_pic"] = Pixmap()
        self["rain_mm_pic"] = Pixmap()
        self["hum_pic"] = Pixmap()
        self["plate1"] = Label()
        self["plate2"] = Label()
        self["plate3"] = Label()
        self["plate5"] = Label()
        self["plate11"] = Label()
        self["plate22"] = Label()
        self["plate33"] = Label()
        self["plate55"] = Label()
        self["day_len"] = Label('0 h 0 min')
        self["sunrise_text"] = Label(_('Sunrise'))
        self["sunrise_val"] = Label('00:00')
        self["sunset_text"] = Label(_('Sunset'))
        self["sunset_val"] = Label('00:00')
        self["sun"] = Pixmap()
        self.color = gRGB(255, 255, 255)

        HelpableScreen.__init__(self)
        self["actions"] = HelpableActionMap(
            self, "ForecaActions",
            {
                "cancel": (self.exit, _("Exit - End")),
                "showEventInfo": (self.info, _("Info - About")),
                "menu": (self.Menu, _("Menu - Select transparency")),
                "left": (self.left, _("Left - Previous day")),
                "right": (self.right, _("Right - Next day")),
                "up": (self.up, _("Up - Previous page")),
                "ok": (self.OK, _("OK - Ext Info")),
                "down": (self.down, _("Down - Next page")),
                "previous": (self.previousDay, _("Left arrow - Previous day")),
                "next": (self.nextDay, _("Right arrow - Next day")),
                "red": (self.red, _("Red - Color select")),
                "green": (self.Fav1, _("Green - Favorite 1")),
                "yellow": (self.Fav2, _("Yellow - Favorite 2")),
                "blue": (self.Fav0, _("Blue - Home")),
                "0": (boundFunction(self.keyNumberGlobal, 0), _("0 - Today")),
                "1": (boundFunction(self.keyNumberGlobal, 1), _("1 - Today + 1 day")),
                "2": (boundFunction(self.keyNumberGlobal, 2), _("2 - Today + 2 days")),
                "3": (boundFunction(self.keyNumberGlobal, 3), _("3 - Today + 3 days")),
                "4": (boundFunction(self.keyNumberGlobal, 4), _("4 - Today + 4 days")),
                "5": (boundFunction(self.keyNumberGlobal, 5), _("5 - Today + 5 days")),
                "6": (boundFunction(self.keyNumberGlobal, 6), _("6 - Today + 6 days")),
                "7": (boundFunction(self.keyNumberGlobal, 7), _("7 - Today + 7 days")),
                "8": (boundFunction(self.keyNumberGlobal, 8), _("8 - Today + 8 days")),
                "9": (boundFunction(self.keyNumberGlobal, 9), _("9 - Today + 9 days")),
            },
            -2
        )

        self.onLayoutFinish.append(self.StartPageFirst)
        self.onShow.append(self.update_button)

    def Menu(self):
        self.session.open(TransparencyBox)

    def OK(self):
        PY3 = version_info[0] == 3
        if PY3:
            self.session.open(ExtInfo_Foreca4_FHD)
        else:
            self.session.open(ExtInfo_2_Foreca4_FHD)

    def savesetcolor(self, indata):
        f = open('/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/set_color.conf', 'w')
        f.write(indata)
        f.close()

    def savesetalpha(self, indata1):
        f = open('/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/set_alpha.conf', 'w')
        f.write(indata1)
        f.close()

    def readsetcolor(self):
        global rgbmyr, rgbmyg, rgbmyb
        rgbmyr = 0
        rgbmyg = 80
        rgbmyb = 239
        if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/set_color.conf") is True:
            try:
                with open("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/set_color.conf", "r") as file:
                    contents = file.readlines()
                    a = str(contents[0])
                    rez = a.rstrip()
                    rgbmyr = rez.split(' ')[0]
                    rgbmyg = rez.split(' ')[1]
                    rgbmyb = rez.split(' ')[2]
                    file.close()
            except:
                rgbmyr = 0
                rgbmyg = 80
                rgbmyb = 239
        else:
            rgbmyr = 0
            rgbmyg = 80
            rgbmyb = 239

    def readsetalpha(self):
        global alpha
        alpha = '#10000000'
        if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/set_alpha.conf") is True:
            try:
                with open("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/set_alpha.conf", "r") as file:
                    contents = file.readlines()
                    a = str(contents[0])
                    alpha = a.rstrip()
                    file.close()
            except:
                alpha = '#10000000'
        else:
            alpha = '#10000000'


    def update_button(self):
        global rgbmyr, rgbmyg, rgbmyb, alpha
        self.color = gRGB(int(rgbmyr), int(rgbmyg), int(rgbmyb))
        self["plate1"].instance.setBackgroundColor(self.color)
        self["plate2"].instance.setBackgroundColor(self.color)
        self["plate3"].instance.setBackgroundColor(self.color)
        self["plate5"].instance.setBackgroundColor(self.color)
        self["plate11"].instance.setBackgroundColor(parseColor(alpha))
        self["plate22"].instance.setBackgroundColor(parseColor(alpha))
        self["plate33"].instance.setBackgroundColor(parseColor(alpha))
        self["plate55"].instance.setBackgroundColor(parseColor(alpha))

        self.my_cur_weather()
        self.my_forecast_weather()

    def StartPageFirst(self):
        global town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, f_date, lon, lat, sunrise, daylen, sunset, f_day
        self.readsetcolor()
        self.readsetalpha()
        self["pic"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/d000.png")
        self["pic"].instance.show()
        self["wind"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/wS.png")
        self["wind"].instance.show()
        self["pressure_pic"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/barometer.png")
        self["pressure_pic"].instance.show()
        self["rain_mm_pic"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/precipitation.png")
        self["rain_mm_pic"].instance.show()
        self["hum_pic"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/humidity.png")
        self["hum_pic"].instance.show()
        self["sun"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/sun.png")
        self["sun"].instance.show()
        self["mytitel1"].text = _("Current weather and forecast")
        self["mytitel2"].text = _("<< ver. ") + str(VERSION) + ' >>'
        self["Titel"].text = _(str(town)) + ', ' + _(str(country)) + ' - ' + str(f_date[0]) + ' - ' + _(f_day)
        self["day_len"].setText(str(conv_day_len(daylen)))
        self["sunrise_val"].setText(str(sunrise))
        self["sunset_val"].setText(str(sunset))

        Thread0 = Thread(target=self.mypicload)
        Thread0.start()

    def mypicload(self):
        global lon, lat
        download_pic = '/tmp/385.png ' + 'https://map-cf.foreca.net/teaser/map/light/rain/6/' + str(lon) + '/' + str(lat) + '/317/385.png?names'
        try:
            os.system('wget -O ' + str(download_pic))
        except:
            pass

    def my_forecast_weather(self):
        global f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum
        self.list = []
        i = len(f_time)
        n = 0
        while n <= i - 1:
            if int(f_cur_temp[n]) >= 0:
                myf_cur_temp = '+' + str(f_cur_temp[n])
            else:
                myf_cur_temp = str(f_cur_temp[n])

            try:
                minipng = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/Foreca4/thumb/" + str(f_symb[n]) + ".png"))
            except:
                minipng = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/Foreca4/thumb/n600.png"))

            try:
                f_myw = int(f_wind[n])
                f_myw1 = self.degreesToWindDirection(f_myw)
                minipng1 = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/Foreca4/thumb/" + str(f_myw1) + ".png"))
            except:
                minipng1 = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/Foreca4/thumb/w360.png"))

            try:
                f_w_s = str(mywindSpeed(f_wind_speed[n], for_wind_speed_recalc)) + ' ' + _('m/s')
            except:
                f_w_s = '0.00' + _('m/s')

            f_description = _(str(self.symbolToCondition(str(f_symb[n]))))

            if int(f_flike_temp[n]) >= 0:
                myf_flike_temp = '+' + str(f_flike_temp[n])
            else:
                myf_flike_temp = str(f_flike_temp[n])

            pos8 = _('Feels like: ') + str(myf_flike_temp) + six.ensure_str(six.unichr(176)) + 'C'

            pos9 = _('Precipitations:') + ' ' + str(f_precipitation[n]) + '%'

            pos10 = _('Humidity:') + ' ' + str(f_rel_hum[n]) + '%'

            self.list.append((str(f_time[n]), _('Temp'), minipng, str(myf_cur_temp) + six.ensure_str(six.unichr(176)) + 'C', minipng1, _('Wind'), str(f_w_s), str(f_description), str(pos8), str(pos9), str(pos10)))
            n = n + 1

        self["menu"].setList(self.list)

    def my_cur_weather(self):
        global town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, lon, lat, sunrise, daylen, sunset
        self["town"].setText(_(str(town)))
        self["cur_temp"].setText(str(cur_temp) + six.ensure_str(six.unichr(176)) + 'C')
        self["fl_temp"].setText(_('Feels like ') + str(fl_temp) + six.ensure_str(six.unichr(176)) + 'C')
        self["dewpoint"].setText(_('Dewpoint ') + ' ' + str(dewpoint) + six.ensure_str(six.unichr(176)) + 'C')

        try:
            self["pic"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(pic) + ".png")
            self["pic"].instance.show()
        except:
            self["pic"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/n600.png")
            self["pic"].instance.show()

        try:
            myw = int(wind.split('w')[1])
            myw1 = self.degreesToWindDirection(myw)
            self["wind"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(myw1) + ".png")
            self["wind"].instance.show()
        except:
            self["wind"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/w360.png")
            self["wind"].instance.show()

        try:
            self["wind_speed"].setText(_('Wind speed ') + str(mywindSpeed(wind_speed, cur_wind_speed_recalc)) + ' ' + _('m/s'))
        except:
            self["wind_speed"].setText(_('Wind speed ') + ' n/a' + ' ' + _('m/s'))

        try:
            self["wind_gust"].setText(_('Gust ') + '  ' + str(mywindSpeed(wind_gust, cur_wind_speed_recalc)) + ' ' + _('m/s'))
        except:
            self["wind_gust"].setText(_('Gust ') + '  ' + ' n/a' + ' ' + _('m/s'))

        self["rain_mm"].setText(str(rain_mm) + ' ' + _('mm'))
        self["hum"].setText(str(hum) + '%')
        self["pressure"].setText(str(pressure) + ' ' + _('mmHg') + '.')
        self["description_w"].setText(_(str(self.symbolToCondition(str(pic)))))

    def StartPage(self):
        global town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, f_date, lon, lat, sunrise, daylen, sunset, f_day
        self["Titel"].text = _(str(town)) + ', ' + _(str(country)) + ' - ' + str(f_date[0]) + ' - ' + _(f_day)
        self["mytitel1"].text = _("Current weather and forecast")
        self["mytitel2"].text = _("<< ver. ") + str(VERSION) + ' >>'
        self["Titel3"].text = ""
        self["Titel5"].text = ""
        self["Titel2"].text = _("Please wait ...")

    def exit(self):
        global rgbmyr, rgbmyg, rgbmyb, myloc, alpha
        rez = str(rgbmyr) + ' ' + str(rgbmyg) + ' ' + str(rgbmyb)
        transp = alpha
        self.savesetcolor(rez)
        self.savesetalpha(transp)
        self.close()

    def keyNumberGlobal(self, number):
        self.tag = number
        self.Zukunft(self.tag)

    def titel(self):
        self.setTitle(_("Foreca Weather Forecast") + " " + _("v.") + VERSION)

    def Fav0(self):
        global start, myloc, town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, lon, lat, sunrise, daylen, sunset, f_day
        myloc = 0
        MAIN_PAGE_F = str(BASEURL) + path_loc0
        town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, lon, lat, sunrise, daylen, sunset = getPageF(MAIN_PAGE_F)
        self.my_cur_weather()

        MAIN_PAGE_FF = str(BASEURL) + path_loc0 + '/hourly?day=0'
        f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, f_day = getPageF_F(MAIN_PAGE_FF)
        self.my_forecast_weather()

        self["day_len"].setText(str(conv_day_len(daylen)))
        self["sunrise_val"].setText(str(sunrise))
        self["sunset_val"].setText(str(sunset))

        Thread1 = Thread(target=self.mypicload)
        Thread1.start()

        self.titel()
        self.Zukunft(0)

    def Fav1(self):
        global fav1, fav2, myloc, town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, lon, lat, sunrise, daylen, sunset, f_day
        myloc = 1
        MAIN_PAGE_F = str(BASEURL) + path_loc1
        town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, lon, lat, sunrise, daylen, sunset = getPageF(MAIN_PAGE_F)
        self.my_cur_weather()

        MAIN_PAGE_FF = str(BASEURL) + path_loc1 + '/hourly?day=0'
        f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, f_day = getPageF_F(MAIN_PAGE_FF)
        self.my_forecast_weather()

        self["day_len"].setText(str(conv_day_len(daylen)))
        self["sunrise_val"].setText(str(sunrise))
        self["sunset_val"].setText(str(sunset))

        Thread2 = Thread(target=self.mypicload)
        Thread2.start()

        self.titel()
        self.Zukunft(0)

    def Fav2(self):
        global myloc, town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, lon, lat, sunrise, daylen, sunset, f_day
        myloc = 2
        MAIN_PAGE_F = str(BASEURL) + path_loc2
        town, cur_temp, fl_temp, dewpoint, pic, wind, wind_speed, wind_gust, rain_mm, hum, pressure, country, lon, lat, sunrise, daylen, sunset = getPageF(MAIN_PAGE_F)
        self.my_cur_weather()

        MAIN_PAGE_FF = str(BASEURL) + path_loc2 + '/hourly?day=0'
        f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, f_day = getPageF_F(MAIN_PAGE_FF)
        self.my_forecast_weather()

        self["day_len"].setText(str(conv_day_len(daylen)))
        self["sunrise_val"].setText(str(sunrise))
        self["sunset_val"].setText(str(sunset))

        Thread3 = Thread(target=self.mypicload)
        Thread3.start()

        self.titel()
        self.Zukunft(0)

    def Zukunft(self, ztag=0):
        global myloc, f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, f_day
        self.tag = ztag

        if myloc == 0:
            MAIN_PAGE_FF = str(BASEURL) + path_loc0 + '/hourly?day=' + str(ztag)
            f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, f_day = getPageF_F(MAIN_PAGE_FF)
            self.my_forecast_weather()
        elif myloc == 1:
            MAIN_PAGE_FF = str(BASEURL) + path_loc1 + '/hourly?day=' + str(ztag)
            f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, f_day = getPageF_F(MAIN_PAGE_FF)
            self.my_forecast_weather()
        elif myloc == 2:
            MAIN_PAGE_FF = str(BASEURL) + path_loc2 + '/hourly?day=' + str(ztag)
            f_town, f_date, f_time, f_symb, f_cur_temp, f_flike_temp, f_wind, f_wind_speed, f_precipitation, f_rel_hum, f_day = getPageF_F(MAIN_PAGE_FF)
            self.my_forecast_weather()

        self.StartPage()

    def info(self):
        self.session.open(InfoBox1)

    def left(self):
        if self.tag > 0:
            self.tag = self.tag - 1
            self.Zukunft(self.tag)

    def right(self):
        if self.tag < 9:
            self.tag = self.tag + 1
            self.Zukunft(self.tag)

    def up(self):
        self["menu"].up()

    def down(self):
        self["menu"].down()

    def previousDay(self):
        self.left()

    def nextDay(self):
        self.right()

    def symbolToCondition(self, symbol):
        symbol_map = {
            'd000': 'Clear', 'n000': 'Clear',
            'd100': 'Mostly clear', 'n100': 'Mostly clear',
            'd200': 'Partly cloudy', 'n200': 'Partly cloudy',
            'd210': 'Partly cloudy and light rain', 'n210': 'Partly cloudy and light rain',
            'd211': 'Partly cloudy and light wet snow', 'n211': 'Partly cloudy and light wet snow',
            'd212': 'Partly cloudy and light snow', 'n212': 'Partly cloudy and light snow',
            'd220': 'Partly cloudy and showers', 'n220': 'Partly cloudy and showers',
            'd221': 'Partly cloudy and wet snow showers', 'n221': 'Partly cloudy and wet snow showers',
            'd222': 'Partly cloudy and snow showers', 'n222': 'Partly cloudy and snow showers',
            'd240': 'Partly cloudy, possible thunderstorms with rain', 'n240': 'Partly cloudy, possible thunderstorms with rain',
            'd300': 'Cloudy', 'n300': 'Cloudy',
            'd310': 'Cloudy and light rain', 'n310': 'Cloudy and light rain',
            'd311': 'Cloudy and light wet snow', 'n311': 'Cloudy and light wet snow',
            'd312': 'Cloudy and light snow', 'n312': 'Cloudy and light snow',
            'd320': 'Cloudy and showers', 'n320': 'Cloudy and showers',
            'd321': 'Cloudy and wet snow showers', 'n321': 'Cloudy and wet snow showers',
            'd322': 'Cloudy and snow showers', 'n322': 'Cloudy and snow showers',
            'd340': 'Cloudy, thunderstorms with rain', 'n340': 'Cloudy, thunderstorms with rain',
            'd400': 'Overcast', 'n400': 'Overcast',
            'd410': 'Overcast and light rain', 'n410': 'Overcast and light rain',
            'd411': 'Overcast and light wet snow', 'n411': 'Overcast and light wet snow',
            'd412': 'Overcast and light snow', 'n412': 'Overcast and light snow',
            'd430': 'Overcast and showers', 'n430': 'Overcast and showers',
            'd421': 'Overcast and wet snow showers', 'n421': 'Overcast and wet snow showers',
            'd432': 'Overcast and snow showers', 'n432': 'Overcast and snow showers',
            'd420': 'Overcast and rain', 'n420': 'Overcast and rain',
            'd431': 'Overcast and wet snow', 'n431': 'Overcast and wet snow',
            'd422': 'Overcast and snow', 'n422': 'Overcast and snow',
            'd440': 'Overcast, thunderstorms with rain', 'n440': 'Overcast, thunderstorms with rain',
            'd500': 'Thin upper cloud', 'n500': 'Thin upper cloud',
            'd600': 'Fog', 'n600': 'Fog'
        }
        return symbol_map.get(symbol, 'Unknown')

    def degreesToWindDirection(self, degrees):
        try:
            directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
            index = round(degrees / 45) % 8
            return "w" + directions[int(index)]
        except:
            return "w360"

    def red(self):
        self.session.open(Color_Select)


class Color_Select(Screen):
    sz_w = getDesktop(0).size().width()
    if sz_w == 1920:
        skin = ColorSelect_FHD
    else:
        skin = ColorSelect_HD

    def __init__(self, session, args=0):
        self.session = session
        Screen.__init__(self, session)

        self.setTitle(_('Color selection'))

        self.Clist = []

        self["Clist"] = MenuList([])
        self["colorname"] = Label()
        self["colorname"].setText(_('n/a'))

        self["colordatas"] = Label()
        self["colordatas"].setText(_('n/a'))

        self.mydata = []
        self["pic1"] = Pixmap()

        self["plate0"] = Label()
        self["plate1"] = Label()

        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions"],
        {
            "cancel": self.Exit,
            "left": self.left,
            "right": self.right,
            "up": self.up,
            "down": self.down,
            "ok": self.OK,
        }, -1)

        self.onShown.append(self.prepare)

    def prepare(self):
        global rgbmyr, rgbmyg, rgbmyb, alpha
        self.color = gRGB(int(rgbmyr), int(rgbmyg), int(rgbmyb))
        self["plate0"].instance.setBackgroundColor(self.color)
        self["plate1"].instance.setBackgroundColor(parseColor(alpha))
        self.maxidx = 0
        if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/" + "new_rgb_full.txt"):
            with open("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/" + "new_rgb_full.txt", "r") as content:
                t = 0
                for line in content:
                    text = line.strip()
                    self.maxidx += 1
                    self.Clist.append(str(t) + '. ' + text.split(' #')[0])
                    self.mydata.append(text.split(' #')[1])
                    t = t + 1
        self["Clist"].l.setList(self.Clist)
        self["Clist"].selectionEnabled(1)
        mycolor = self['Clist'].getCurrent().split('. ')[1]
        myhtml = '#' + self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[0]
        myr = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[1]
        myg = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[2]
        myb = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[3]
        self["colorname"].setText(mycolor)
        self["colordatas"].setText('HTML (' + myhtml + ')   Red (' + myr + ')   Green (' + myg + ')   Blue (' + myb + ')')

        if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + '#000000.png'):
            self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + '#000000.png')
            self["pic1"].instance.show()

    def up(self):
        self["Clist"].up()
        self["Clist"].selectionEnabled(1)
        mycolor = self['Clist'].getCurrent().split('. ')[1]
        myhtml = '#' + self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[0]
        myr = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[1]
        myg = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[2]
        myb = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[3]
        self["colorname"].setText(mycolor)
        self["colordatas"].setText('HTML (' + myhtml + ')   Red (' + myr + ')   Green (' + myg + ')   Blue (' + myb + ')')

        if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + str(myhtml) + '.png'):
            self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + str(myhtml) + '.png')
            self["pic1"].instance.show()

    def down(self):
        self["Clist"].down()
        self["Clist"].selectionEnabled(1)
        mycolor = self['Clist'].getCurrent().split('. ')[1]
        myhtml = '#' + self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[0]
        myr = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[1]
        myg = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[2]
        myb = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[3]
        self["colorname"].setText(mycolor)
        self["colordatas"].setText('HTML (' + myhtml + ')   Red (' + myr + ')   Green (' + myg + ')   Blue (' + myb + ')')

        if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + str(myhtml) + '.png'):
            self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + str(myhtml) + '.png')
            self["pic1"].instance.show()

    def left(self):
        self["Clist"].pageUp()
        self["Clist"].selectionEnabled(1)
        mycolor = self['Clist'].getCurrent().split('. ')[1]
        myhtml = '#' + self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[0]
        myr = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[1]
        myg = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[2]
        myb = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[3]
        self["colorname"].setText(mycolor)
        self["colordatas"].setText('HTML (' + myhtml + ')   Red (' + myr + ')   Green (' + myg + ')   Blue (' + myb + ')')

        if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + str(myhtml) + '.png'):
            self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + str(myhtml) + '.png')
            self["pic1"].instance.show()

    def right(self):
        self["Clist"].pageDown()
        self["Clist"].selectionEnabled(1)
        mycolor = self['Clist'].getCurrent().split('. ')[1]
        myhtml = '#' + self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[0]
        myr = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[1]
        myg = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[2]
        myb = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[3]
        self["colorname"].setText(mycolor)
        self["colordatas"].setText('HTML (' + myhtml + ')   Red (' + myr + ')   Green (' + myg + ')   Blue (' + myb + ')')

        if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + str(myhtml) + '.png'):
            self["pic1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/samples/" + str(myhtml) + '.png')
            self["pic1"].instance.show()

    def OK(self):
        global rgbmyr, rgbmyg, rgbmyb

        rgbmyr = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[1]
        rgbmyg = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[2]
        rgbmyb = self.mydata[int(self['Clist'].getCurrent().split('. ')[0])].split(' ')[3]

        self.close()

    def Exit(self):
        self.close()


class InfoBox1(Screen):
    sz_w = getDesktop(0).size().width()
    if sz_w == 1920:
        skin = About_Foreca4_FHD
    else:
        skin = About_Foreca4_HD

    def __init__(self, session):

        Screen.__init__(self, session)

        self['ver'] = StaticText(_('Foreca 4 Weather and Forecast') + ' ver. ' + str(VERSION))

        self["plate0"] = Label()
        self["plate1"] = Label()

        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions"],
        {
            "cancel": self.Exit,
            'ok': self.Exit,
        }, -1)

        self.onShow.append(self.Start2)

    def Start2(self):
        global rgbmyr, rgbmyg, rgbmyb, alpha
        self.color = gRGB(int(rgbmyr), int(rgbmyg), int(rgbmyb))
        self["plate0"].instance.setBackgroundColor(self.color)
        self["plate1"].instance.setBackgroundColor(parseColor(alpha))

    def Exit(self):
        self.close()


class ExtInfo_Foreca4_FHD(Screen):
    sz_w = getDesktop(0).size().width()
    if sz_w == 1920:
        skin = ExtInfo_Foreca4_FHD
    else:
        skin = ExtInfo_Foreca4_HD

    def __init__(self, session):

        Screen.__init__(self, session)

        global myloc

        if myloc == 0:
            MAIN_PAGE_TT = 'https://www.forecaweather.com/' + str(path_loc0)
        elif myloc == 1:
            MAIN_PAGE_TT = 'https://www.forecaweather.com/' + str(path_loc1)
        elif myloc == 2:
            MAIN_PAGE_TT = 'https://www.forecaweather.com/' + str(path_loc2)

        self.mytown, self.mytext1, self.myh_temp, self.myl_temp, self.mytext2, self.mytext3, self.myh2_temp, self.myl2_temp, self.mytext4, self.mysymb_mo1, self.mysymb_mo2, self.myt_mo1, self.myt_mo2, self.mysymb_af1, self.mysymb_af2, self.myt_af1, self.myt_af2, self.mysymb_ev1, self.mysymb_ev2, self.myt_ev1, self.myt_ev2, self.mysymb_ov1, self.mysymb_ov2, self.myt_ov1, self.myt_ov2 = getPageTT(MAIN_PAGE_TT)

        self['title1'] = StaticText(_('Weather Radar'))
        self['title2'] = StaticText()
        self['title3'] = StaticText(_('Weather today'))
        self['title4'] = StaticText(_('Weather tomorrow'))
        self["TitelOK"] = Label(_("Meteogram"))
        self["pic"] = Pixmap()
        self['text1'] = StaticText()
        self['text2'] = StaticText()
        self['mo1'] = StaticText()
        self['mo2'] = StaticText()
        self['af1'] = StaticText()
        self['af2'] = StaticText()
        self['ev1'] = StaticText()
        self['ev2'] = StaticText()
        self['ov1'] = StaticText()
        self['ov2'] = StaticText()
        self["pic_af1"] = Pixmap()
        self["pic_ev1"] = Pixmap()
        self["pic_ov1"] = Pixmap()
        self["pic_mo1"] = Pixmap()
        self['mo1_text'] = StaticText()
        self['af1_text'] = StaticText()
        self['ev1_text'] = StaticText()
        self['ov1_text'] = StaticText()
        self["pic_af2"] = Pixmap()
        self["pic_ev2"] = Pixmap()
        self["pic_ov2"] = Pixmap()
        self["pic_mo2"] = Pixmap()
        self['mo2'] = StaticText()
        self['af2'] = StaticText()
        self['ev2'] = StaticText()
        self['ov2'] = StaticText()
        self['mo2_text'] = StaticText()
        self['af2_text'] = StaticText()
        self['ev2_text'] = StaticText()
        self['ov2_text'] = StaticText()
        self["plate0"] = Label()
        self["plate1"] = Label()
        self["pic_lot"] = Pixmap()
        self["pic_lat"] = Pixmap()
        self['lat_val'] = StaticText()
        self['lon_val'] = StaticText()

        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions"],
        {
            "cancel": self.Exit,
            'ok': self.OK,
        }, -1)

        self.onLayoutFinish.append(self.Start1)
        self.onShow.append(self.Start2)

    def OK(self):
        self.session.open(Meteogram_Foreca4_FHD)

    def Start2(self):
        self['title3'].text = str('Weather today')
        self['title4'].text = str('Weather tomorrow')

        self['title2'].text = str(self.mytown)

        t1 = str(self.mytext1) + ' ' + str(self.myh_temp) + six.ensure_str(six.unichr(176)) + 'C, ' + str(self.myl_temp) + six.ensure_str(six.unichr(176)) + 'C. ' + str(self.mytext2) + ' mm.'
        self["text1"].text = str(t1)

        t2 = str(self.mytext3) + ' ' + str(self.myh2_temp) + six.ensure_str(six.unichr(176)) + 'C, ' + str(self.myl2_temp) + six.ensure_str(six.unichr(176)) + 'C. ' + str(self.mytext4) + ' mm.'
        self["text2"].text = str(t2)

        self['mo1'].text = _('Morning')
        self['mo2'].text = _('Morning')
        self['af1'].text = _('Afternoon')
        self['af2'].text = _('Afternoon')
        self['ev1'].text = _('Evening')
        self['ev2'].text = _('Evening')
        self['ov1'].text = _('Overnight')
        self['ov2'].text = _('Overnight')

        global rgbmyr, rgbmyg, rgbmyb, alpha
        self.color = gRGB(int(rgbmyr), int(rgbmyg), int(rgbmyb))
        self["plate0"].instance.setBackgroundColor(self.color)
        self["plate1"].instance.setBackgroundColor(parseColor(alpha))

        Thread4 = Thread(target=self.mytranslate)
        Thread4.start()

    def mytranslate(self):
        self['title3'].text = str(trans('Weather today'))
        self['title4'].text = str(trans('Weather tomorrow'))

        self['title2'].text = str(trans(self.mytown))

        t1 = str(self.mytext1) + ' ' + str(self.myh_temp) + six.ensure_str(six.unichr(176)) + 'C, ' + str(self.myl_temp) + six.ensure_str(six.unichr(176)) + 'C. ' + str(self.mytext2) + ' mm.'
        self["text1"].text = str(trans(t1))

        t2 = str(self.mytext3) + ' ' + str(self.myh2_temp) + six.ensure_str(six.unichr(176)) + 'C, ' + str(self.myl2_temp) + six.ensure_str(six.unichr(176)) + 'C. ' + str(self.mytext4) + ' mm.'
        self["text2"].text = str(trans(t2))

    def Start1(self):
        global lon, lat
        if os.path.exists("/tmp/385.png"):
            self["pic"].instance.setPixmapFromFile("/tmp/385.png")
            self["pic"].instance.show()

        self["pic_af1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(self.mysymb_af1) + ".png")
        self["pic_af1"].instance.show()
        self["pic_ev1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(self.mysymb_ev1) + ".png")
        self["pic_ev1"].instance.show()
        self["pic_ov1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(self.mysymb_ov1) + ".png")
        self["pic_ov1"].instance.show()
        self["pic_mo1"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(self.mysymb_mo1) + ".png")
        self["pic_mo1"].instance.show()

        self["pic_af2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(self.mysymb_af2) + ".png")
        self["pic_af2"].instance.show()
        self["pic_ev2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(self.mysymb_ev2) + ".png")
        self["pic_ev2"].instance.show()
        self["pic_ov2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(self.mysymb_ov2) + ".png")
        self["pic_ov2"].instance.show()
        self["pic_mo2"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/thumb/" + str(self.mysymb_mo2) + ".png")
        self["pic_mo2"].instance.show()

        self["pic_lot"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/longitude.png")
        self["pic_lot"].instance.show()
        self["pic_lat"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/latitude.png")
        self["pic_lat"].instance.show()

        self['mo1_text'].text = str(self.myt_mo1)
        self['af1_text'].text = str(self.myt_af1)
        self['ev1_text'].text = str(self.myt_ev1)
        self['ov1_text'].text = str(self.myt_ov1)

        self['mo2_text'].text = str(self.myt_mo2)
        self['af2_text'].text = str(self.myt_af2)
        self['ev2_text'].text = str(self.myt_ev2)
        self['ov2_text'].text = str(self.myt_ov2)

        self['lat_val'].text = str(lat)
        self['lon_val'].text = str(lon)

    def Exit(self):
        self.close()


class ExtInfo_2_Foreca4_FHD(Screen):
    sz_w = getDesktop(0).size().width()
    if sz_w == 1920:
        skin = ExtInfo_2_Foreca4_FHD
    else:
        skin = ExtInfo_2_Foreca4_HD

    def __init__(self, session):

        Screen.__init__(self, session)

        self['title1'] = StaticText(_('Weather Radar'))
        self["pic"] = Pixmap()
        self["plate0"] = Label()
        self["plate1"] = Label()
        self["pic_lot"] = Pixmap()
        self["pic_lat"] = Pixmap()
        self['lat_val'] = StaticText()
        self['lon_val'] = StaticText()

        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions"],
        {
            "cancel": self.Exit,
            'ok': self.OK,
        }, -1)

        self.onLayoutFinish.append(self.Start1)
        self.onShow.append(self.Start2)

    def Start2(self):
        global rgbmyr, rgbmyg, rgbmyb, alpha
        self.color = gRGB(int(rgbmyr), int(rgbmyg), int(rgbmyb))
        self["plate0"].instance.setBackgroundColor(self.color)
        self["plate1"].instance.setBackgroundColor(parseColor(alpha))

    def Start1(self):
        global lon, lat
        if os.path.exists("/tmp/385.png"):
            self["pic"].instance.setPixmapFromFile("/tmp/385.png")
            self["pic"].instance.show()

        self["pic_lot"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/longitude.png")
        self["pic_lot"].instance.show()
        self["pic_lat"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/latitude.png")
        self["pic_lat"].instance.show()

        self['lat_val'].text = str(lat)
        self['lon_val'].text = str(lon)

    def OK(self):
        self.session.open(Meteogram_Foreca4_FHD)

    def Exit(self):
        self.close()


class TransparencyBox(Screen):
    sz_w = getDesktop(0).size().width()
    if sz_w == 1920:
        skin = Transparency_Foreca4_FHD
    else:
        skin = Transparency_Foreca4_HD

    def __init__(self, session):

        Screen.__init__(self, session)

        self["list"] = MenuList([])
        self['text1'] = StaticText(_('Window transparency'))

        self["plate0"] = Label()
        self["plate1"] = Label()

        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions", "ShortcutActions", "WizardActions"],
        {
            "cancel": self.Exit,
            "ok": self.Ok,
        }, -1)

        self.onShow.append(self.Start2)


    def Start2(self):
        global rgbmyr, rgbmyg, rgbmyb, alpha
        self.color = gRGB(int(rgbmyr), int(rgbmyg), int(rgbmyb))
        self["plate0"].instance.setBackgroundColor(self.color)
        self["plate1"].instance.setBackgroundColor(parseColor(alpha))
        self['text1'].text = (_('Window transparency') + ' - ' + conv_alpha(alpha))

        list = []

        list.append(_("Transparency level") + " 56% " + "#90000000")  # 90
        list.append(_("Transparency level") + " 50% " + "#80000000")  # 80
        list.append(_("Transparency level") + " 44% " + "#70000000")  # 70
        list.append(_("Transparency level") + " 38% " + "#60000000")  # 60
        list.append(_("Transparency level") + " 31% " + "#50000000")  # 50
        list.append(_("Transparency level") + " 25% " + "#40000000")  # 40
        list.append(_("Transparency level") + " 19% " + "#30000000")  # 30
        list.append(_("Transparency level") + " 13% " + "#20000000")  # 20
        list.append(_("Transparency level") + " 06% " + "#10000000")  # 10
        self["list"].setList(list)


    def Ok(self):
        global alpha

        sel = self["list"].getCurrent().split(' ')[2]
        if sel == "#90000000":
            alpha = '#90000000'
            self.close()
        elif sel == "#80000000":
            alpha = '#80000000'
            self.close()
        elif sel == "#70000000":
            alpha = '#70000000'
            self.close()
        elif sel == "#60000000":
            alpha = '#60000000'
            self.close()
        elif sel == "#50000000":
            alpha = '#50000000'
            self.close()
        elif sel == "#40000000":
            alpha = '#40000000'
            self.close()
        elif sel == "#30000000":
            alpha = '#30000000'
            self.close()
        elif sel == "#20000000":
            alpha = '#20000000'
            self.close()
        elif sel == "#10000000":
            alpha = '#10000000'
            self.close()


    def Exit(self):
        self.close()


class Meteogram_Foreca4_FHD(Screen):
    sz_w = getDesktop(0).size().width()
    if sz_w == 1920:
        skin = Meteogram_Foreca4_FHD
    else:
        skin = Meteogram_Foreca4_HD

    def __init__(self, session):

        global share_town0, myloc

        Screen.__init__(self, session)

        if myloc == 0:
            self['title1'] = StaticText(_('Meteogram') + str(share_town0))
        else:
            self['title1'] = StaticText(_('Meteogram'))

        self["pic"] = Pixmap()
        self["plate0"] = Label()
        self["plate1"] = Label()

        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "HelpActions", "EPGSelectActions"],
        {
            "cancel": self.Exit,
            'ok': self.Exit,
        }, -1)

        self.onLayoutFinish.append(self.Start1)
        self.onShow.append(self.Start2)

    def Start2(self):
        global rgbmyr, rgbmyg, rgbmyb, alpha
        self.color = gRGB(int(rgbmyr), int(rgbmyg), int(rgbmyb))
        self["plate0"].instance.setBackgroundColor(self.color)
        self["plate1"].instance.setBackgroundColor(parseColor(alpha))

    def Start1(self):
        global myloc
        if myloc == 0:
            if os.path.exists("/tmp/foreca_com_2_w.png"):
                self["pic"].instance.setPixmapFromFile("/tmp/foreca_com_2_w.png")
                self["pic"].instance.show()
            else:
                self["pic"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/no_data.png")
                self["pic"].instance.show()
        else:
            self["pic"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/Foreca4/images/no_data.png")
            self["pic"].instance.show()

    def Exit(self):
        self.close()


def main(session, **kwargs):
    session.open(ForecaPreview_4)


def Plugins(path, **kwargs):
    list = [PluginDescriptor(
        name=_("Foreca 4") + " ver. " + str(VERSION),
        description=_("Current weather and forecast for the next 10 days"),
        icon="foreca_4.png",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main)
    ]
    return list
