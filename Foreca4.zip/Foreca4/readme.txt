Foreca API Map System (FULLY IMPLEMENTED)

Authentication: Read from api_config.txt → JWT token (30 days)
Dynamic Layers: Show layers menu from /api/v1/capabilities (Temperature, Precipitation, Wind, Clouds, Pressure, etc.)
Viewer: 3x3 grid tiles, timeline, overlay on background maps
Cache: Unified foreca4_map_cache/ folder for tokens, capabilities, and tiles
Integration: "Foreca Live Maps (API)" menu item in the main plugin
Background Mapping System
Smart mapping layer → background PNG:
temperature → temp_map.png
precipitation → rain_map.png
cloud → cloud_map.png
pressure → pressure_map.png
wind → europa.png (fallback - no wind_map.png) (existing)
radar → rain_map.png
Hierarchical fallback: regional map → europe.png

End User Documentation
Registration Guide: https://developer.foreca.com (FREE 30-day trial)

Configuration: Create api_config.txt with:
API_USER=your_user
API_PASSWORD=your_password
TOKEN_EXPIRE_HOURS=720
MAP_SERVER=map-eu.foreca.com
AUTH_SERVER=pfa.foreca.com

CRITICAL LINKS AND RESOURCES
Official API Documentation: https://developer.foreca.com
Trial Registration: Module on developer.foreca.com (1000 requests/day)
Available PNG Backgrounds: /thumb/[temp|rain|cloud|pressure]_map.png + regional maps
Old Plugin (reference): https://github.com/Belfagor2005/e2openplugin-Foreca/blob/master/plugin/ui.py
Configuration File: Foreca4/api_config.txt (template in api_config.txt.example)

CURRENT LIMITS/CONSIDERATIONS
Trial Account: 1000 tile requests/day, expires after 30 days
Mandatory Attribution: Show "Foreca" + specific attributions for radar/satellite data
Wind Map Background: No existing wind_map.png → use europa.png as background
Satellite Data: API supports satellite layers (EUMETSAT/NOAA) but not yet implemented

@Lululla